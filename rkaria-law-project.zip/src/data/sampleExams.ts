/**
 * R. KARIA PUBLICATION – LAW STUDENT PAPER SOLUTION
 * Initial Sample Examinations (Including the 200-Question AIBE Mock Test)
 */

import { Exam } from '../types';

export const INITIAL_EXAMS: Exam[] = [
  {
    id: 'aibe-full-200-mock',
    title: 'AIBE Full-Length Online Mock Examination (200 Questions)',
    titleGu: 'AIBE સંપૂર્ણ મોક પરીક્ષા (૨૦૦ પ્રશ્નો)',
    description: 'Complete 200-question All India Bar Examination (AIBE) model test covering Constitutional Law, IPC/BNS, CrPC/BNSS, Evidence/BSA, CPC, Family Law, ADR, and Professional Ethics with detailed legal explanations.',
    descriptionGu: 'ઓલ ઇન્ડિયા બાર એક્ઝામિનેશન (AIBE) માટેની સંપૂર્ણ ૨૦૦ પ્રશ્નોની ઓનલાઈન મોક ટેસ્ટ. કલમો, સીમાચિહ્ન ચુકાદાઓ અને ગુજરાતી-અંગ્રેજી સમજૂતી સાથે.',
    category: 'AIBE Mock Test',
    durationMinutes: 180, // 3 Hours
    totalQuestions: 200,
    totalMarks: 200,
    passingMarks: 80, // 40%
    negativeMarking: false,
    negativeMarkingValue: 0,
    isPublished: true,
    questionIds: Array.from({ length: 200 }, (_, i) => `q-${i + 1}`),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'aibe-subject-consti-50',
    title: 'Constitutional Law & Writs Special Test (50 Questions)',
    titleGu: 'બંધારણીય કાયદો અને રીટ વિશેષ ટેસ્ટ (૫૦ પ્રશ્નો)',
    description: 'Focused MCQ test covering Fundamental Rights (Arts. 14, 19, 21, 32), Directive Principles, Federal Structure, and Judicial Review.',
    descriptionGu: 'મૂળભૂત અધિકારો, માર્ગદર્શક સિદ્ધાંતો અને બંધારણીય રીટ સંબંધિત ૫૦ પ્રશ્નોની વિશેષ પરીક્ષા.',
    category: 'Subject-Wise MCQ Test',
    durationMinutes: 50,
    totalQuestions: 50,
    totalMarks: 50,
    passingMarks: 20,
    negativeMarking: false,
    negativeMarkingValue: 0,
    isPublished: true,
    questionIds: Array.from({ length: 50 }, (_, i) => `q-${i + 1}`),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'aibe-subject-criminal-50',
    title: 'Criminal Major Acts – IPC/BNS & CrPC/BNSS (50 Questions)',
    titleGu: 'ફોજદારી કાયદા – IPC/BNS અને CrPC/BNSS (૫૦ પ્રશ્નો)',
    description: 'Master General Exceptions, Offences Against Body & Property, Bail Provisions, Cognizable Offences, and FIR mandatory guidelines.',
    descriptionGu: 'સામાન્ય અપવાદો, શરીર અને મિલકત વિરુદ્ધના ગુનાઓ, જામીન જોગવાઈઓ અને એફઆઈઆર સંબંધિત ૫૦ પ્રશ્નો.',
    category: 'Subject-Wise MCQ Test',
    durationMinutes: 50,
    totalQuestions: 50,
    totalMarks: 50,
    passingMarks: 20,
    negativeMarking: false,
    negativeMarkingValue: 0,
    isPublished: true,
    questionIds: Array.from({ length: 50 }, (_, i) => `q-${(i % 50) + 1}`),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'aibe-practice-quick-30',
    title: 'AIBE Daily Practice Speed Drill (30 Questions)',
    titleGu: 'AIBE દૈનિક ઝડપી પ્રેક્ટિસ ટેસ્ટ (૩૦ પ્રશ્નો)',
    description: 'Quick 30-minute practice examination designed for daily revision on mobile devices.',
    descriptionGu: 'મોબાઇલ પર ઝડપી રિવિઝન માટે ૩૦ મિનિટની દૈનિક પ્રેક્ટિસ ટેસ્ટ.',
    category: 'Practice Examination',
    durationMinutes: 30,
    totalQuestions: 30,
    totalMarks: 30,
    passingMarks: 12,
    negativeMarking: false,
    negativeMarkingValue: 0,
    isPublished: true,
    questionIds: Array.from({ length: 30 }, (_, i) => `q-${i + 1}`),
    createdAt: new Date().toISOString(),
  },
];
