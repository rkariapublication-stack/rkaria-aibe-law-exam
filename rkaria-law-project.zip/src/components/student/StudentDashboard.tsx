import React, { useState } from 'react';
import {
  BookOpen,
  Clock,
  Award,
  CheckCircle2,
  XCircle,
  FileText,
  Play,
  TrendingUp,
  BarChart3,
  Calendar,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { Exam, ExamAttempt, Student } from '../../types';
import { getAllExams, getAttemptsByStudent } from '../../services/storage';

interface Props {
  currentStudent: Student | null;
  onStartExam: (exam: Exam) => void;
  onViewAttempt: (attempt: ExamAttempt) => void;
  onOpenRegisterModal: () => void;
  language: 'en' | 'gu';
}

export const StudentDashboard: React.FC<Props> = ({
  currentStudent,
  onStartExam,
  onViewAttempt,
  onOpenRegisterModal,
  language,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const allExams = getAllExams().filter((e) => e.isPublished);
  const studentAttempts = currentStudent ? getAttemptsByStudent(currentStudent.id) : [];

  const categories = [
    { id: 'All', labelEn: 'All Examinations', labelGu: 'તમામ પરીક્ષાઓ' },
    { id: 'AIBE Mock Test', labelEn: 'AIBE 200 Mock Tests', labelGu: 'AIBE ૨૦૦ મોક ટેસ્ટ' },
    { id: 'Subject-Wise MCQ Test', labelEn: 'Subject-Wise Tests', labelGu: 'વિષયવાર પરીક્ષાઓ' },
    { id: 'Practice Examination', labelEn: 'Practice Tests', labelGu: 'પ્રેક્ટિસ ડ્રીલ' },
  ];

  const filteredExams =
    selectedCategory === 'All'
      ? allExams
      : allExams.filter((e) => e.category === selectedCategory);

  // Performance calculations
  const totalAttempts = studentAttempts.length;
  const passedCount = studentAttempts.filter((a) => a.isPassed).length;
  const avgPercentage =
    totalAttempts > 0
      ? Math.round(
          studentAttempts.reduce((acc, a) => acc + a.percentage, 0) / totalAttempts
        )
      : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-8">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-r from-[#23201d] via-[#3d2f26] to-[#1e1b18] text-white p-6 sm:p-10 shadow-xl border border-[#8c4e28]/30">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none flex items-center justify-end pr-6">
          <img
            src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
            alt="Watermark"
            className="h-full object-contain"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#c47a46]/20 border border-[#c47a46]/40 text-[#f5caa6] text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>R. KARIA PUBLICATION – ALL INDIA BAR EXAMINATION (AIBE)</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-bold font-serif-legal tracking-tight text-[#fdfbf7]">
            {currentStudent
              ? language === 'gu'
                ? `નમસ્તે, ${currentStudent.fullName}`
                : `Welcome, ${currentStudent.fullName}`
              : language === 'gu'
              ? 'ઓલ ઇન્ડિયા બાર એક્ઝામિનેશન (AIBE) મોક ટેસ્ટ પોર્ટલ'
              : 'All India Bar Examination (AIBE) Mock Portal'}
          </h2>

          <p className="mt-2 text-sm sm:text-base text-[#d1c4b4] leading-relaxed">
            {language === 'gu'
              ? 'AIBE માટે ૨૦૦ પ્રશ્નોની સંપૂર્ણ ઓનલાઇન મોક પરીક્ષા આપો. પરીક્ષા સબમિટ કર્યા પછી ત્વરિત માર્ક્સ, ટકાવારી અને દરેક પ્રશ્નની કાયદાકીય કલમ અને કેસ લો સાથે વિસ્તૃત સમજૂતી મેળવો.'
              : 'Prepare for AIBE with authentic 200-question computer-based mock tests. Gain confidence with real-time countdown timers, instant automated scoring, and detailed legal explanations in English & Gujarati.'}
          </p>

          {!currentStudent && (
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                onClick={onOpenRegisterModal}
                className="flex items-center gap-2 rounded-xl bg-[#c47a46] hover:bg-[#a86132] text-white px-5 py-2.5 font-bold text-sm shadow-lg transition"
              >
                <span>{language === 'gu' ? 'વિદ્યાર્થી નોંધણી કરો (મફત)' : 'Student Registration (Free)'}</span>
                <Play className="w-4 h-4 fill-current" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Student Performance Stats Cards (if registered) */}
      {currentStudent && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-2xl bg-white p-4 sm:p-5 border border-[#e8dfd3] shadow-xs">
            <div className="flex items-center justify-between text-[#8c4e28] mb-2">
              <span className="text-xs font-bold uppercase tracking-wide text-[#7a6f62]">
                {language === 'gu' ? 'કુલ પ્રયાસો' : 'Exams Attempted'}
              </span>
              <FileText className="w-5 h-5 text-[#8c4e28]" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-[#1e1b18]">{totalAttempts}</p>
            <p className="text-[11px] text-[#7a6f62] mt-1">
              {language === 'gu' ? 'સફળતાપૂર્વક સબમિટ કરેલ' : 'Completed submissions'}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-4 sm:p-5 border border-[#e8dfd3] shadow-xs">
            <div className="flex items-center justify-between text-emerald-600 mb-2">
              <span className="text-xs font-bold uppercase tracking-wide text-[#7a6f62]">
                {language === 'gu' ? 'ઉત્તીર્ણ (Pass)' : 'AIBE Qualified'}
              </span>
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-700">{passedCount}</p>
            <p className="text-[11px] text-[#7a6f62] mt-1">
              {language === 'gu' ? '૪૦% કે તેથી વધુ માર્ક્સ' : 'Score ≥ 40% threshold'}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-4 sm:p-5 border border-[#e8dfd3] shadow-xs">
            <div className="flex items-center justify-between text-[#8c4e28] mb-2">
              <span className="text-xs font-bold uppercase tracking-wide text-[#7a6f62]">
                {language === 'gu' ? 'સરેરાશ સ્કોર' : 'Average Score'}
              </span>
              <TrendingUp className="w-5 h-5 text-[#8c4e28]" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-[#1e1b18]">{avgPercentage}%</p>
            <p className="text-[11px] text-[#7a6f62] mt-1">
              {language === 'gu' ? 'તમામ પરીક્ષાઓની સરેરાશ' : 'Across all examinations'}
            </p>
          </div>

          <div className="rounded-2xl bg-white p-4 sm:p-5 border border-[#e8dfd3] shadow-xs">
            <div className="flex items-center justify-between text-[#8c4e28] mb-2">
              <span className="text-xs font-bold uppercase tracking-wide text-[#7a6f62]">
                {language === 'gu' ? 'વિદ્યાર્થી પ્રોફાઇલ' : 'Account Mobile'}
              </span>
              <Award className="w-5 h-5 text-[#8c4e28]" />
            </div>
            <p className="text-lg sm:text-xl font-bold text-[#1e1b18] truncate font-mono">
              +91 {currentStudent.mobileNumber}
            </p>
            <p className="text-[11px] text-[#7a6f62] mt-1">
              {language === 'gu' ? 'સક્રિય વિદ્યાર્થી ખાતું' : 'Verified Student ID'}
            </p>
          </div>
        </div>
      )}

      {/* Available Examinations Section */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
              {language === 'gu' ? 'ઉપલબ્ધ પરીક્ષાઓ (Available Exams)' : 'Available Examinations'}
            </h3>
            <p className="text-xs text-[#7a6f62]">
              {language === 'gu'
                ? 'તમારી અનુકૂળતા મુજબ ૨૦૦ પ્રશ્નોની સંપૂર્ણ પરીક્ષા અથવા વિષયવાર ટેસ્ટ પસંદ કરો.'
                : 'Select a 200-question full-length AIBE mock test or subject-specific drill.'}
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                  selectedCategory === c.id
                    ? 'bg-[#8c4e28] text-white shadow-xs'
                    : 'bg-white text-[#5c5042] border border-[#e0d6c8] hover:bg-[#f5efe6]'
                }`}
              >
                {language === 'gu' ? c.labelGu : c.labelEn}
              </button>
            ))}
          </div>
        </div>

        {/* Exam Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExams.map((exam) => (
            <div
              key={exam.id}
              className="flex flex-col justify-between rounded-2xl bg-white border border-[#e8dfd3] p-5 sm:p-6 shadow-xs hover:shadow-md transition hover:border-[#8c4e28]/50 group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full bg-[#8c4e28]/10 text-[#8c4e28] tracking-wider">
                    {exam.category}
                  </span>
                  <span className="text-xs font-bold text-[#7a6f62] flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#8c4e28]" />
                    {exam.durationMinutes} {language === 'gu' ? 'મિનિટ' : 'Mins'}
                  </span>
                </div>

                <h4 className="text-base sm:text-lg font-bold text-[#1e1b18] group-hover:text-[#8c4e28] transition font-serif-legal line-clamp-2">
                  {language === 'gu' && exam.titleGu ? exam.titleGu : exam.title}
                </h4>

                <p className="mt-2 text-xs text-[#6e6357] line-clamp-3 leading-relaxed">
                  {language === 'gu' && exam.descriptionGu ? exam.descriptionGu : exam.description}
                </p>

                {/* Exam Key Specs */}
                <div className="mt-4 pt-3 border-t border-[#f0e8dc] grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-lg bg-[#fdfbf7] border border-[#f0e8dc]">
                    <p className="text-[10px] text-[#7a6f62] uppercase font-bold">
                      {language === 'gu' ? 'પ્રશ્નો' : 'Questions'}
                    </p>
                    <p className="text-sm font-extrabold text-[#1e1b18]">{exam.totalQuestions}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-[#fdfbf7] border border-[#f0e8dc]">
                    <p className="text-[10px] text-[#7a6f62] uppercase font-bold">
                      {language === 'gu' ? 'કુલ માર્ક્સ' : 'Total Marks'}
                    </p>
                    <p className="text-sm font-extrabold text-[#1e1b18]">{exam.totalMarks}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-[#fdfbf7] border border-[#f0e8dc]">
                    <p className="text-[10px] text-[#7a6f62] uppercase font-bold">
                      {language === 'gu' ? 'પાસિંગ માર્ક્સ' : 'Passing (40%)'}
                    </p>
                    <p className="text-sm font-extrabold text-emerald-600">{exam.passingMarks}</p>
                  </div>
                </div>
              </div>

              {/* Start Button */}
              <button
                onClick={() => {
                  if (!currentStudent) {
                    onOpenRegisterModal();
                  } else {
                    onStartExam(exam);
                  }
                }}
                className="mt-6 w-full flex items-center justify-center gap-2 rounded-xl bg-[#8c4e28] group-hover:bg-[#703b1c] text-white py-2.5 font-bold text-xs sm:text-sm shadow-xs transition"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{language === 'gu' ? 'પરીક્ષા શરૂ કરો' : 'Start Examination'}</span>
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Previous Examination Results Section (if attempts exist) */}
      {currentStudent && studentAttempts.length > 0 && (
        <div className="mt-12">
          <div className="mb-4">
            <h3 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
              {language === 'gu' ? 'અગાઉની પરીક્ષાઓના પરિણામો' : 'Previous Examination Results'}
            </h3>
            <p className="text-xs text-[#7a6f62]">
              {language === 'gu'
                ? 'તમે આપેલી તમામ પરીક્ષાઓનો ઇતિહાસ. સંપૂર્ણ સોલ્યુશન અને સમજૂતી જોવા માટે ક્લિક કરો.'
                : 'Your examination performance history and complete answer solutions.'}
            </p>
          </div>

          <div className="space-y-3">
            {studentAttempts.map((attempt) => (
              <div
                key={attempt.id}
                className="flex flex-col md:flex-row md:items-center justify-between rounded-2xl bg-white border border-[#e8dfd3] p-4 sm:p-5 shadow-xs hover:border-[#8c4e28]/40 transition gap-4"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        attempt.isPassed
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {attempt.isPassed ? 'AIBE QUALIFIED (PASS)' : 'NEEDS REVISION'}
                    </span>
                    <span className="text-xs text-[#7a6f62] flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {new Date(attempt.submittedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <h4 className="text-base font-bold text-[#1e1b18]">{attempt.examTitle}</h4>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-[#6e6357]">
                    <span>
                      {language === 'gu' ? 'કુલ પ્રશ્નો: ' : 'Total: '}
                      <strong>{attempt.totalQuestions}</strong>
                    </span>
                    <span className="text-emerald-700">
                      {language === 'gu' ? 'સાચા: ' : 'Correct: '}
                      <strong>{attempt.correctAnswers}</strong>
                    </span>
                    <span className="text-red-600">
                      {language === 'gu' ? 'ખોટા: ' : 'Wrong: '}
                      <strong>{attempt.wrongAnswers}</strong>
                    </span>
                    <span>
                      {language === 'gu' ? 'સમય: ' : 'Time Taken: '}
                      <strong>{Math.floor(attempt.timeTakenSeconds / 60)} mins</strong>
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 border-t md:border-t-0 pt-3 md:pt-0 border-[#f0e8dc]">
                  <div className="text-right">
                    <p className="text-xs text-[#7a6f62] font-semibold">
                      {language === 'gu' ? 'મેળવેલ ગુણ' : 'Score'}
                    </p>
                    <p className="text-xl font-extrabold text-[#8c4e28]">
                      {attempt.totalMarksScored} / {attempt.maxMarks}
                      <span className="text-xs font-normal ml-1">({attempt.percentage}%)</span>
                    </p>
                  </div>

                  <button
                    onClick={() => onViewAttempt(attempt)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#23201d] hover:bg-black text-[#fdfbf7] text-xs font-bold transition shadow-xs"
                  >
                    <FileText className="w-3.5 h-3.5 text-[#c47a46]" />
                    <span>{language === 'gu' ? 'પેપર સોલ્યુશન જુઓ' : 'View Solution'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
