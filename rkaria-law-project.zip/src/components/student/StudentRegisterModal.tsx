import React, { useState } from 'react';
import { User, Phone, ArrowRight, X, BookOpen, ShieldCheck } from 'lucide-react';
import { registerOrLoginStudent } from '../../services/storage';
import { Student } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (student: Student) => void;
  language: 'en' | 'gu';
}

export const StudentRegisterModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSuccess,
  language,
}) => {
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanName = fullName.trim();
    const cleanMobile = mobileNumber.trim().replace(/\D/g, '');

    if (!cleanName || cleanName.length < 3) {
      setError(
        language === 'gu'
          ? 'કૃપા કરીને તમારું પૂરું નામ લખો (ઓછામાં ઓછા ૩ અક્ષર).'
          : 'Please enter your full name (minimum 3 characters).'
      );
      return;
    }

    if (!cleanMobile || cleanMobile.length !== 10) {
      setError(
        language === 'gu'
          ? 'કૃપા કરીને માન્ય ૧૦ આંકડાનો મોબાઇલ નંબર દાખલ કરો.'
          : 'Please enter a valid 10-digit mobile number.'
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const { student, isExisting } = registerOrLoginStudent(cleanName, cleanMobile);
      setIsSubmitting(false);
      onSuccess(student);
      onClose();
    } catch {
      setIsSubmitting(false);
      setError('An error occurred during registration. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-[#fdfbf7] p-6 sm:p-8 shadow-2xl border border-[#c47a46]/20 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rounded-full p-1.5 text-[#8c4e28]/60 hover:text-[#8c4e28] hover:bg-[#8c4e28]/10 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Emblem */}
        <div className="text-center mb-6">
          <div className="mx-auto w-16 h-16 rounded-2xl overflow-hidden border-2 border-[#8c4e28]/30 bg-[#1e1b18] p-1 shadow-md mb-3 flex items-center justify-center">
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
              alt="R. Karia Publication Logo"
              className="w-full h-full object-contain"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/icon.svg';
              }}
            />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
            R. KARIA PUBLICATION
          </h2>
          <p className="text-xs font-semibold text-[#8c4e28] tracking-wider uppercase mt-0.5">
            {language === 'gu' ? 'વિદ્યાર્થી નોંધણી અને પ્રવેશ' : 'Student Registration & Access'}
          </p>
          <p className="text-xs text-[#6e6357] mt-2">
            {language === 'gu'
              ? 'AIBE ઓનલાઇન મોક પરીક્ષા શરૂ કરવા માટે તમારું નામ અને મોબાઇલ નંબર દાખલ કરો.'
              : 'Enter your details to attempt AIBE mock examinations & view your previous scorecards.'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#3a332a] mb-1.5 uppercase tracking-wide">
              {language === 'gu' ? 'વિદ્યાર્થીનું પૂરું નામ' : 'Student Full Name'} *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8c4e28]">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder={language === 'gu' ? 'દા.ત. અમીત શર્મા' : 'e.g. Adv. Amit Sharma'}
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#d6c7b6] bg-white text-sm text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28] focus:border-transparent transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#3a332a] mb-1.5 uppercase tracking-wide">
              {language === 'gu' ? 'મોબાઇલ નંબર' : 'Mobile Number'} *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8c4e28]">
                <Phone className="w-4 h-4" />
              </div>
              <span className="absolute inset-y-0 left-9 flex items-center text-xs font-semibold text-[#8c4e28] pointer-events-none">
                +91
              </span>
              <input
                type="tel"
                maxLength={10}
                required
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                placeholder="9876543210"
                className="w-full pl-18 pr-3.5 py-2.5 rounded-xl border border-[#d6c7b6] bg-white text-sm text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28] focus:border-transparent transition font-mono"
              />
            </div>
            <p className="text-[11px] text-[#7a6f62] mt-1">
              {language === 'gu'
                ? 'OTP વગર સીધો પ્રવેશ. એક મોબાઇલ નંબર = એક વિદ્યાર્થી ખાતું.'
                : 'Direct access without OTP. One mobile number = One student account.'}
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-2 flex items-center justify-center gap-2 rounded-xl bg-[#8c4e28] hover:bg-[#703b1c] text-white py-3 font-bold text-sm shadow-md transition disabled:opacity-50"
          >
            <span>{language === 'gu' ? 'નોંધણી કરો અને આગળ વધો' : 'Register & Continue'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-5 pt-4 border-t border-[#e8dfd3] flex items-center justify-center gap-2 text-[11px] text-[#7a6f62]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>
            {language === 'gu'
              ? 'તમારી વિગતો સુરક્ષિત છે. પરીક્ષા ઇતિહાસ આપમેળે સચવાશે.'
              : 'Your data is secured. Exam records auto-sync with your mobile.'}
          </span>
        </div>
      </div>
    </div>
  );
};
