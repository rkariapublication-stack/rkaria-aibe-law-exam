import React, { useState } from 'react';
import {
  Users,
  BookOpen,
  FileSpreadsheet,
  Settings,
  BarChart3,
  LogOut,
  Plus,
  Trash2,
  Edit3,
  Search,
  Download,
  Upload,
  Share2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar,
  Clock,
  ExternalLink,
  Copy,
  ChevronRight,
  Shield,
  HelpCircle,
  Eye,
  FileText,
} from 'lucide-react';
import { Exam, ExamAttempt, Question, Student, Subject } from '../../types';
import {
  getAllExams,
  getAllQuestions,
  getAllStudents,
  getAllAttempts,
  saveQuestion,
  deleteQuestion,
  bulkImportQuestions,
  saveExam,
  deleteExam,
  exportFullBackupJSON,
  importFullBackupJSON,
  setAdminAuthenticated,
} from '../../services/storage';
import {
  downloadFile,
  exportAttemptsToCSV,
  exportStudentsToCSV,
  generateSampleQuestionsCSV,
  parseAndValidateQuestionsCSV,
  generateWhatsAppShareData,
} from '../../services/exportService';

interface Props {
  onBackToApp: () => void;
  language: 'en' | 'gu';
}

export const AdminDashboard: React.FC<Props> = ({ onBackToApp, language }) => {
  const [activeTab, setActiveTab] = useState<
    'analytics' | 'students' | 'audit' | 'questions' | 'upload' | 'exams' | 'backup' | 'guide'
  >('analytics');

  // State
  const [questions, setQuestions] = useState<Question[]>(getAllQuestions());
  const [exams, setExams] = useState<Exam[]>(getAllExams());
  const [students, setStudents] = useState<Student[]>(getAllStudents());
  const [attempts, setAttempts] = useState<ExamAttempt[]>(getAllAttempts());

  // Search & Filters
  const [studentSearch, setStudentSearch] = useState('');
  const [questionSearch, setQuestionSearch] = useState('');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState('All');

  // Selected student for audit
  const [selectedStudentForAudit, setSelectedStudentForAudit] = useState<Student | null>(null);
  const [selectedAttemptForAudit, setSelectedAttemptForAudit] = useState<ExamAttempt | null>(null);

  // Question editing / creation modal
  const [isEditingQuestion, setIsEditingQuestion] = useState(false);
  const [questionFormData, setQuestionFormData] = useState<Partial<Question>>({
    subject: 'Constitutional Law',
    correctAnswer: 'A',
  });

  // Exam editing / creation modal
  const [isEditingExam, setIsEditingExam] = useState(false);
  const [examFormData, setExamFormData] = useState<Partial<Exam>>({
    category: 'AIBE Mock Test',
    durationMinutes: 180,
    totalQuestions: 200,
    totalMarks: 200,
    passingMarks: 80,
    negativeMarking: false,
    isPublished: true,
  });

  // Bulk upload status
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const [uploadSuccessMessage, setUploadSuccessMessage] = useState<string | null>(null);

  // Copy notification
  const [copiedLinkExamId, setCopiedLinkExamId] = useState<string | null>(null);

  // Refresh helper
  const reloadData = () => {
    setQuestions(getAllQuestions());
    setExams(getAllExams());
    setStudents(getAllStudents());
    setAttempts(getAllAttempts());
  };

  const handleLogout = () => {
    setAdminAuthenticated(false);
    onBackToApp();
  };

  // Analytics
  const totalStudentsCount = students.length;
  const totalExamsCount = exams.length;
  const totalAttemptsCount = attempts.length;
  const passedAttemptsCount = attempts.filter((a) => a.isPassed).length;
  const avgMarksScored =
    totalAttemptsCount > 0
      ? (attempts.reduce((acc, a) => acc + a.totalMarksScored, 0) / totalAttemptsCount).toFixed(1)
      : '0';
  const highestMarksScored =
    totalAttemptsCount > 0
      ? Math.max(...attempts.map((a) => a.totalMarksScored))
      : 0;
  const lowestMarksScored =
    totalAttemptsCount > 0
      ? Math.min(...attempts.map((a) => a.totalMarksScored))
      : 0;

  // Question bank handlers
  const handleSaveQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionFormData.questionText || !questionFormData.optionA || !questionFormData.correctAnswer) {
      alert('Please fill all required question fields.');
      return;
    }

    const newQ: Question = {
      id: questionFormData.id || `q-custom-${Date.now()}`,
      questionText: questionFormData.questionText,
      questionTextGu: questionFormData.questionTextGu || questionFormData.questionText,
      optionA: questionFormData.optionA,
      optionAGu: questionFormData.optionAGu || questionFormData.optionA,
      optionB: questionFormData.optionB || '',
      optionBGu: questionFormData.optionBGu || questionFormData.optionB,
      optionC: questionFormData.optionC || '',
      optionCGu: questionFormData.optionCGu || questionFormData.optionC,
      optionD: questionFormData.optionD || '',
      optionDGu: questionFormData.optionDGu || questionFormData.optionD,
      correctAnswer: questionFormData.correctAnswer as 'A' | 'B' | 'C' | 'D',
      explanation: questionFormData.explanation || '',
      explanationGu: questionFormData.explanationGu || questionFormData.explanation,
      subject: questionFormData.subject || 'Constitutional Law',
      legalSection: questionFormData.legalSection,
      caseLaw: questionFormData.caseLaw,
    };

    saveQuestion(newQ);
    reloadData();
    setIsEditingQuestion(false);
    setQuestionFormData({ subject: 'Constitutional Law', correctAnswer: 'A' });
  };

  const handleDeleteQuestion = (id: string) => {
    if (confirm('Are you sure you want to delete this question?')) {
      deleteQuestion(id);
      reloadData();
    }
  };

  // Exam handlers
  const handleSaveExamSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examFormData.title) {
      alert('Exam Title is required');
      return;
    }

    // Default select up to 200 questions if not manually selected
    const qIds =
      examFormData.questionIds && examFormData.questionIds.length > 0
        ? examFormData.questionIds
        : questions.slice(0, examFormData.totalQuestions || 200).map((q) => q.id);

    const newExam: Exam = {
      id: examFormData.id || `exam-${Date.now()}`,
      title: examFormData.title,
      titleGu: examFormData.titleGu || examFormData.title,
      description: examFormData.description || '',
      descriptionGu: examFormData.descriptionGu || examFormData.description,
      category: examFormData.category || 'AIBE Mock Test',
      durationMinutes: Number(examFormData.durationMinutes) || 180,
      totalQuestions: qIds.length,
      totalMarks: Number(examFormData.totalMarks) || 200,
      passingMarks: Number(examFormData.passingMarks) || 80,
      negativeMarking: Boolean(examFormData.negativeMarking),
      isPublished: examFormData.isPublished !== undefined ? examFormData.isPublished : true,
      questionIds: qIds,
      createdAt: examFormData.createdAt || new Date().toISOString(),
    };

    saveExam(newExam);
    reloadData();
    setIsEditingExam(false);
  };

  const handleDeleteExam = (id: string) => {
    if (confirm('Are you sure you want to delete this examination?')) {
      deleteExam(id);
      reloadData();
    }
  };

  // Bulk Upload File Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadFile(file);
    setUploadErrors([]);
    setUploadSuccessMessage(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const result = parseAndValidateQuestionsCSV(content);

      if (result.errors.length > 0) {
        setUploadErrors(result.errors);
      }

      if (result.validQuestions.length > 0) {
        const imported = bulkImportQuestions(result.validQuestions);
        reloadData();
        setUploadSuccessMessage(
          `Successfully validated and imported ${imported.count} new questions! Question bank now contains ${imported.total} questions.`
        );
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-[#f7f4ed] flex flex-col">
      {/* Admin Top Header */}
      <header className="sticky top-0 z-30 bg-[#1e1b18] text-white border-b border-[#3d362e] shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-white/10 p-1 border border-[#c47a46]/40 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                alt="Logo"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-lg font-bold font-serif-legal text-[#fdfbf7]">
                  R. KARIA PUBLICATION
                </h1>
                <span className="text-[10px] bg-[#c47a46] text-white font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Admin Portal
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-[#b8a99a] tracking-wider uppercase">
                Law Student Paper Solution – Examination & Question Bank Manager
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onBackToApp}
              className="px-3 py-1.5 rounded-xl border border-[#c47a46]/50 bg-white/5 hover:bg-white/10 text-xs font-semibold text-[#f5caa6] transition"
            >
              View Student App
            </button>
            <button
              onClick={handleLogout}
              className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-700/50 text-xs font-semibold text-red-200 transition flex items-center gap-1"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto flex gap-1 border-t border-[#2e2822] py-2 text-xs">
          {[
            { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            { id: 'students', label: `Students (${totalStudentsCount})`, icon: Users },
            { id: 'questions', label: `Question Bank (${questions.length})`, icon: BookOpen },
            { id: 'upload', label: 'Bulk CSV / Excel Upload', icon: Upload },
            { id: 'exams', label: `Examinations (${exams.length})`, icon: Settings },
            { id: 'backup', label: 'Export & Backup', icon: FileSpreadsheet },
            { id: 'guide', label: 'Free Hosting Guide (ગુજરાતી)', icon: HelpCircle },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition ${
                  isActive
                    ? 'bg-[#c47a46] text-white shadow-xs'
                    : 'text-[#d9cdbf] hover:bg-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {/* TAB 1: ANALYTICS */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                Publication Examination Analytics
              </h2>
              <p className="text-xs text-[#7a6f62]">
                Real-time dashboard monitoring student registrations, examination attempts, and scoring metrics.
              </p>
            </div>

            {/* Metric KPI cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs">
                <p className="text-xs font-bold text-[#7a6f62] uppercase">Registered Students</p>
                <p className="text-3xl font-extrabold text-[#1e1b18] mt-1">{totalStudentsCount}</p>
                <p className="text-[11px] text-[#8c4e28] mt-1">Single-mobile verified</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs">
                <p className="text-xs font-bold text-[#7a6f62] uppercase">Total Exam Attempts</p>
                <p className="text-3xl font-extrabold text-[#1e1b18] mt-1">{totalAttemptsCount}</p>
                <p className="text-[11px] text-emerald-700 mt-1">
                  {passedAttemptsCount} passed ({totalAttemptsCount > 0 ? Math.round((passedAttemptsCount / totalAttemptsCount) * 100) : 0}%)
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs">
                <p className="text-xs font-bold text-[#7a6f62] uppercase">Average Marks</p>
                <p className="text-3xl font-extrabold text-[#8c4e28] mt-1">{avgMarksScored}</p>
                <p className="text-[11px] text-[#7a6f62] mt-1">Highest: {highestMarksScored} | Lowest: {lowestMarksScored}</p>
              </div>

              <div className="p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs">
                <p className="text-xs font-bold text-[#7a6f62] uppercase">Question Bank</p>
                <p className="text-3xl font-extrabold text-[#1e1b18] mt-1">{questions.length}</p>
                <p className="text-[11px] text-[#8c4e28] mt-1">200-question tests ready</p>
              </div>
            </div>

            {/* Quick Actions & Recent Submissions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* WhatsApp Share Card */}
              <div className="lg:col-span-1 rounded-2xl bg-linear-to-br from-[#23201d] to-[#3a2d24] text-white p-6 shadow-md border border-[#8c4e28]/40 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-[#c47a46] mb-3">
                    <Share2 className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase tracking-wider">Direct WhatsApp Share</span>
                  </div>
                  <h3 className="text-lg font-bold font-serif-legal">Share Examination with Students</h3>
                  <p className="text-xs text-[#d4c6b8] mt-2 leading-relaxed">
                    Send one-click WhatsApp invitations with student instructions and public exam URL.
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 space-y-2">
                  {exams.slice(0, 2).map((ex) => {
                    const waData = generateWhatsAppShareData(ex.title, ex.totalQuestions, ex.id);
                    return (
                      <a
                        key={ex.id}
                        href={waData.waShareUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs"
                      >
                        <span className="truncate max-w-[200px]">Share: {ex.title}</span>
                        <Share2 className="w-4 h-4 shrink-0" />
                      </a>
                    );
                  })}
                </div>
              </div>

              {/* Recent Examination Submissions */}
              <div className="lg:col-span-2 rounded-2xl bg-white border border-[#e5dcd1] p-6 shadow-xs">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-[#1e1b18] text-base font-serif-legal">
                    Recent Examination Submissions
                  </h3>
                  <button
                    onClick={() => setActiveTab('students')}
                    className="text-xs font-bold text-[#8c4e28] hover:underline"
                  >
                    View All Students →
                  </button>
                </div>

                {attempts.length === 0 ? (
                  <p className="text-xs text-[#7a6f62] py-8 text-center">
                    No examination submissions yet. Share your WhatsApp exam link to begin receiving attempts!
                  </p>
                ) : (
                  <div className="divide-y divide-[#f0e8dc] text-xs">
                    {attempts.slice(0, 5).map((att) => (
                      <div key={att.id} className="py-3 flex items-center justify-between gap-3">
                        <div>
                          <p className="font-bold text-[#1e1b18]">{att.studentName}</p>
                          <p className="text-[11px] text-[#7a6f62]">
                            +91 {att.studentMobile} • {att.examTitle}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-extrabold text-[#8c4e28]">
                            {att.totalMarksScored} / {att.maxMarks} ({att.percentage}%)
                          </p>
                          <span
                            className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              att.isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {att.isPassed ? 'PASS' : 'FAIL'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: STUDENT MANAGEMENT */}
        {activeTab === 'students' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                  Student Management
                </h2>
                <p className="text-xs text-[#7a6f62]">
                  Registered students directory. Click any student to view their complete examination history and answers.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const csv = exportStudentsToCSV(students, attempts);
                    downloadFile(csv, `RKaria_Students_${Date.now()}.csv`);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#d8cdbf] text-xs font-bold text-[#1e1b18] hover:bg-[#f5efe6] transition"
                >
                  <Download className="w-3.5 h-3.5 text-[#8c4e28]" />
                  <span>Export Students CSV</span>
                </button>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative max-w-md">
              <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#8c4e28]" />
              <input
                type="text"
                placeholder="Search by student name or mobile number..."
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#d8cdbf] bg-white text-xs text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28]"
              />
            </div>

            {/* Students Table */}
            <div className="overflow-x-auto rounded-2xl border border-[#e5dcd1] bg-white shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8f4ec] border-b border-[#e5dcd1] text-[#6e6357] font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Mobile Number</th>
                    <th className="p-3.5">Registration Date</th>
                    <th className="p-3.5">Total Exams</th>
                    <th className="p-3.5">Last Exam Date</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0e8dc]">
                  {students
                    .filter((s) => {
                      const query = studentSearch.toLowerCase();
                      return (
                        s.fullName.toLowerCase().includes(query) ||
                        s.mobileNumber.includes(query)
                      );
                    })
                    .map((st) => {
                      const studentAttempts = attempts.filter((a) => a.studentId === st.id);
                      const last = studentAttempts[0];

                      return (
                        <tr
                          key={st.id}
                          className="hover:bg-[#fdfbf7] cursor-pointer transition"
                          onClick={() => {
                            setSelectedStudentForAudit(st);
                            setActiveTab('audit');
                          }}
                        >
                          <td className="p-3.5 font-bold text-[#1e1b18]">{st.fullName}</td>
                          <td className="p-3.5 font-mono text-[#8c4e28] font-semibold">+91 {st.mobileNumber}</td>
                          <td className="p-3.5 text-[#7a6f62]">{new Date(st.registeredAt).toLocaleDateString()}</td>
                          <td className="p-3.5 font-bold">{studentAttempts.length}</td>
                          <td className="p-3.5 text-[#7a6f62]">
                            {last ? new Date(last.submittedAt).toLocaleDateString() : 'None'}
                          </td>
                          <td className="p-3.5 text-right">
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#8c4e28] hover:underline">
                              <span>Audit History</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: STUDENT EXAMINATION REPORTS & QUESTION AUDIT */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#e5dcd1]">
              <div>
                <h2 className="text-xl font-bold text-[#1e1b18] font-serif-legal">
                  Student Examination Audit & Answer Inspection
                </h2>
                <p className="text-xs text-[#7a6f62]">
                  {selectedStudentForAudit
                    ? `Inspecting records for ${selectedStudentForAudit.fullName} (+91 ${selectedStudentForAudit.mobileNumber})`
                    : 'Select a student from Student Management to view their examination answers.'}
                </p>
              </div>
              <button
                onClick={() => setActiveTab('students')}
                className="px-3 py-1.5 rounded-xl border border-[#d8cdbf] bg-white text-xs font-bold text-[#8c4e28]"
              >
                ← Back to Student List
              </button>
            </div>

            {selectedStudentForAudit && (
              <div className="space-y-6">
                {/* Student's Attempts List */}
                <div className="space-y-3">
                  <h3 className="text-sm font-bold text-[#1e1b18] uppercase tracking-wide">
                    Examination History
                  </h3>
                  {attempts.filter((a) => a.studentId === selectedStudentForAudit.id).length === 0 ? (
                    <p className="p-4 rounded-xl bg-white border border-[#e5dcd1] text-xs text-[#7a6f62]">
                      This student has not attempted any examinations yet.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {attempts
                        .filter((a) => a.studentId === selectedStudentForAudit.id)
                        .map((att) => (
                          <div
                            key={att.id}
                            onClick={() => setSelectedAttemptForAudit(att)}
                            className={`p-4 rounded-xl border cursor-pointer transition ${
                              selectedAttemptForAudit?.id === att.id
                                ? 'bg-[#8c4e28]/10 border-[#8c4e28] ring-2 ring-[#8c4e28]'
                                : 'bg-white border-[#e5dcd1] hover:border-[#8c4e28]/40'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="font-bold text-xs text-[#1e1b18]">{att.examTitle}</h4>
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  att.isPassed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {att.isPassed ? 'PASSED' : 'FAILED'}
                              </span>
                            </div>
                            <div className="mt-2 text-xs flex justify-between text-[#7a6f62]">
                              <span>Score: {att.totalMarksScored} / {att.maxMarks} ({att.percentage}%)</span>
                              <span>{new Date(att.submittedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Question-by-Question Audit of Selected Attempt */}
                {selectedAttemptForAudit && (
                  <div className="mt-6 rounded-2xl bg-white border border-[#e5dcd1] p-5 sm:p-6 shadow-xs space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-[#e5dcd1]">
                      <div>
                        <h4 className="font-bold text-base text-[#1e1b18]">
                          Individual Answer Audit: {selectedAttemptForAudit.examTitle}
                        </h4>
                        <p className="text-xs text-[#7a6f62]">
                          Student: {selectedAttemptForAudit.studentName} | Score: {selectedAttemptForAudit.totalMarksScored} / {selectedAttemptForAudit.maxMarks}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                      {Object.entries(selectedAttemptForAudit.answers).map(([qId, ans], idx) => {
                        const q = questions.find((item) => item.id === qId);
                        if (!q) return null;
                        const isCorrect = ans.selectedOption === q.correctAnswer;
                        const isSkipped = !ans.selectedOption;

                        return (
                          <div
                            key={qId}
                            className={`p-4 rounded-xl border text-xs ${
                              isCorrect
                                ? 'bg-emerald-50/50 border-emerald-200'
                                : isSkipped
                                ? 'bg-gray-50 border-gray-200'
                                : 'bg-red-50/50 border-red-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="font-bold font-mono text-[#8c4e28]">
                                Question {idx + 1} ({q.subject})
                              </span>
                              <span
                                className={`font-bold px-2 py-0.5 rounded-md text-[10px] ${
                                  isCorrect
                                    ? 'bg-emerald-600 text-white'
                                    : isSkipped
                                    ? 'bg-gray-400 text-white'
                                    : 'bg-red-600 text-white'
                                }`}
                              >
                                {isCorrect ? 'Correct' : isSkipped ? 'Skipped' : 'Wrong Choice'}
                              </span>
                            </div>

                            <p className="font-semibold text-[#1e1b18] mb-2">{q.questionText}</p>

                            <div className="grid grid-cols-2 gap-2 text-[11px] mb-2">
                              <div className="p-2 rounded-lg bg-white border border-[#e5dcd1]">
                                <strong>Candidate Selected: </strong>
                                <span className={isCorrect ? 'text-emerald-700 font-bold' : 'text-red-700 font-bold'}>
                                  {ans.selectedOption || 'None (Unanswered)'}
                                </span>
                              </div>
                              <div className="p-2 rounded-lg bg-emerald-100 border border-emerald-300 text-emerald-950">
                                <strong>Official Correct Answer: </strong>
                                <span className="font-bold">{q.correctAnswer}</span>
                              </div>
                            </div>

                            <p className="text-[#554b3f] text-[11px]">
                              <strong>Explanation:</strong> {q.explanation}
                            </p>
                            {q.legalSection && (
                              <p className="text-[#8c4e28] text-[11px] font-semibold mt-1">
                                Statutory Provision: {q.legalSection}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: QUESTION BANK MANAGEMENT */}
        {activeTab === 'questions' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                  Question Bank Management ({questions.length} Questions)
                </h2>
                <p className="text-xs text-[#7a6f62]">
                  Add, edit, search, and manage legal MCQs with statutory sections and landmark case laws.
                </p>
              </div>

              <button
                onClick={() => {
                  setQuestionFormData({
                    subject: 'Constitutional Law',
                    correctAnswer: 'A',
                  });
                  setIsEditingQuestion(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#8c4e28] hover:bg-[#723e1e] text-white text-xs font-bold shadow-xs transition"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Question</span>
              </button>
            </div>

            {/* Filter & Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-3 text-[#8c4e28]" />
                <input
                  type="text"
                  placeholder="Search questions by keyword, legal section, case law..."
                  value={questionSearch}
                  onChange={(e) => setQuestionSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 rounded-xl border border-[#d8cdbf] bg-white text-xs text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28]"
                />
              </div>

              <select
                value={selectedSubjectFilter}
                onChange={(e) => setSelectedSubjectFilter(e.target.value)}
                className="px-3 py-2 rounded-xl border border-[#d8cdbf] bg-white text-xs text-[#1e1b18]"
              >
                <option value="All">All Subjects</option>
                <option value="Constitutional Law">Constitutional Law</option>
                <option value="Indian Penal Code / BNS">Indian Penal Code / BNS</option>
                <option value="Criminal Procedure Code / BNSS">Criminal Procedure Code / BNSS</option>
                <option value="Indian Evidence Act / BSA">Indian Evidence Act / BSA</option>
                <option value="Code of Civil Procedure (CPC)">Code of Civil Procedure (CPC)</option>
                <option value="Law of Contract & Specific Relief">Law of Contract & Specific Relief</option>
                <option value="Family Law (Hindu & Muslim)">Family Law (Hindu & Muslim)</option>
                <option value="Arbitration & ADR">Arbitration & ADR</option>
                <option value="Professional Ethics & Bar Council Rules">Professional Ethics & BCI Rules</option>
                <option value="Public Interest Litigation (PIL)">Public Interest Litigation (PIL)</option>
              </select>
            </div>

            {/* Questions List */}
            <div className="space-y-3">
              {questions
                .filter((q) => {
                  const query = questionSearch.toLowerCase();
                  const matchesSearch =
                    q.questionText.toLowerCase().includes(query) ||
                    (q.questionTextGu && q.questionTextGu.toLowerCase().includes(query)) ||
                    (q.legalSection && q.legalSection.toLowerCase().includes(query)) ||
                    (q.caseLaw && q.caseLaw.toLowerCase().includes(query));
                  const matchesSubject =
                    selectedSubjectFilter === 'All' || q.subject === selectedSubjectFilter;
                  return matchesSearch && matchesSubject;
                })
                .slice(0, 50) // Paginated window for performance
                .map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-4 sm:p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs text-xs space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold font-mono text-white bg-[#8c4e28] px-2 py-0.5 rounded-md text-[10px]">
                          #{idx + 1}
                        </span>
                        <span className="font-bold text-[#8c4e28] px-2 py-0.5 rounded-md bg-[#8c4e28]/10 text-[10px]">
                          {q.subject}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setQuestionFormData(q);
                            setIsEditingQuestion(true);
                          }}
                          className="p-1 text-[#8c4e28] hover:bg-[#8c4e28]/10 rounded-lg transition"
                          title="Edit Question"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteQuestion(q.id)}
                          className="p-1 text-red-600 hover:bg-red-50 rounded-lg transition"
                          title="Delete Question"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="font-bold text-[#1e1b18] text-sm leading-relaxed">{q.questionText}</h4>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                      {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                        <div
                          key={opt}
                          className={`p-2 rounded-lg border ${
                            q.correctAnswer === opt
                              ? 'bg-emerald-100 border-emerald-400 font-bold text-emerald-950'
                              : 'bg-[#fdfbf7] border-[#eee5d9] text-[#554b3f]'
                          }`}
                        >
                          <strong>{opt}: </strong>
                          {q[`option${opt}` as keyof Question] as string}
                        </div>
                      ))}
                    </div>

                    <p className="text-[#6e6357] text-[11px] pt-2 border-t border-[#f0e8dc]">
                      <strong>Explanation: </strong> {q.explanation}
                    </p>

                    <div className="flex flex-wrap gap-2 text-[10px]">
                      {q.legalSection && (
                        <span className="px-2 py-0.5 rounded-md bg-[#8c4e28]/10 text-[#8c4e28] font-semibold">
                          ⚖️ {q.legalSection}
                        </span>
                      )}
                      {q.caseLaw && (
                        <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 font-semibold border border-blue-200">
                          📖 {q.caseLaw}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* TAB 5: BULK CSV / EXCEL UPLOAD */}
        {activeTab === 'upload' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                Excel & CSV Bulk Question Upload
              </h2>
              <p className="text-xs text-[#7a6f62]">
                Import up to 200 or more questions instantly using a CSV or Excel spreadsheet. Automated validation checks for missing options, invalid answers, and missing explanations.
              </p>
            </div>

            {/* Template Download Card */}
            <div className="p-5 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-sm text-[#1e1b18]">Sample Excel / CSV Template</h3>
                <p className="text-xs text-[#7a6f62] mt-0.5">
                  Download the official R. Karia Publication column template with bilingual sample questions.
                </p>
              </div>
              <button
                onClick={() => {
                  const sample = generateSampleQuestionsCSV();
                  downloadFile(sample, 'RKaria_Sample_Questions_Template.csv');
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#8c4e28] hover:bg-[#723e1e] text-white text-xs font-bold shadow-xs transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Sample Template</span>
              </button>
            </div>

            {/* File Drag and Drop Box */}
            <div className="rounded-2xl border-2 border-dashed border-[#c47a46]/50 bg-white p-8 sm:p-12 text-center hover:bg-[#fdfbf7] transition">
              <Upload className="w-10 h-10 text-[#8c4e28] mx-auto mb-3" />
              <h3 className="font-bold text-base text-[#1e1b18]">Upload Question Bank CSV</h3>
              <p className="text-xs text-[#7a6f62] mt-1 max-w-md mx-auto">
                Select your prepared CSV file containing questions, options A-D, correct answer key, and legal explanations.
              </p>

              <label className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#1e1b18] hover:bg-black text-white text-xs font-bold cursor-pointer transition shadow-md">
                <span>Choose File to Upload</span>
                <input
                  type="file"
                  accept=".csv,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Success Feedback */}
            {uploadSuccessMessage && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{uploadSuccessMessage}</span>
              </div>
            )}

            {/* Error Feedback */}
            {uploadErrors.length > 0 && (
              <div className="p-5 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-red-700">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Validation Errors Detected ({uploadErrors.length})</span>
                </div>
                <p className="text-[11px] text-red-700">
                  Please fix the following line items in your spreadsheet before importing:
                </p>
                <ul className="list-disc pl-5 space-y-1 font-mono text-[11px]">
                  {uploadErrors.slice(0, 10).map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                  {uploadErrors.length > 10 && (
                    <li>...and {uploadErrors.length - 10} more errors.</li>
                  )}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* TAB 6: EXAMINATION MANAGEMENT */}
        {activeTab === 'exams' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                  Examination Management
                </h2>
                <p className="text-xs text-[#7a6f62]">
                  Configure 200-question papers, timers, negative marking, and generate direct WhatsApp share links.
                </p>
              </div>

              <button
                onClick={() => {
                  setExamFormData({
                    category: 'AIBE Mock Test',
                    durationMinutes: 180,
                    totalQuestions: 200,
                    totalMarks: 200,
                    passingMarks: 80,
                    negativeMarking: false,
                    isPublished: true,
                  });
                  setIsEditingExam(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#8c4e28] hover:bg-[#723e1e] text-white text-xs font-bold shadow-xs transition"
              >
                <Plus className="w-4 h-4" />
                <span>Create New Exam</span>
              </button>
            </div>

            {/* Examinations List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {exams.map((ex) => {
                const wa = generateWhatsAppShareData(ex.title, ex.totalQuestions, ex.id);
                return (
                  <div
                    key={ex.id}
                    className="p-5 sm:p-6 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#8c4e28]/10 text-[#8c4e28] uppercase">
                          {ex.category}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            ex.isPublished
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-gray-200 text-gray-700'
                          }`}
                        >
                          {ex.isPublished ? 'PUBLISHED' : 'DRAFT'}
                        </span>
                      </div>

                      <h3 className="font-bold text-base text-[#1e1b18] font-serif-legal">{ex.title}</h3>
                      <p className="text-xs text-[#6e6357] mt-1 line-clamp-2">{ex.description}</p>

                      <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs pt-3 border-t border-[#f0e8dc]">
                        <div className="p-2 rounded-lg bg-[#fdfbf7]">
                          <p className="text-[10px] text-[#7a6f62] uppercase font-bold">Questions</p>
                          <p className="font-extrabold text-[#1e1b18]">{ex.totalQuestions}</p>
                        </div>
                        <div className="p-2 rounded-lg bg-[#fdfbf7]">
                          <p className="text-[10px] text-[#7a6f62] uppercase font-bold">Duration</p>
                          <p className="font-extrabold text-[#1e1b18]">{ex.durationMinutes}m</p>
                        </div>
                        <div className="p-2 rounded-lg bg-[#fdfbf7]">
                          <p className="text-[10px] text-[#7a6f62] uppercase font-bold">Pass Cut-off</p>
                          <p className="font-extrabold text-emerald-700">{ex.passingMarks} marks</p>
                        </div>
                      </div>
                    </div>

                    {/* WhatsApp Share Link Box */}
                    <div className="pt-3 border-t border-[#f0e8dc] space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <a
                          href={wa.waShareUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                          <span>WhatsApp Share</span>
                        </a>

                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(wa.examUrl);
                            setCopiedLinkExamId(ex.id);
                            setTimeout(() => setCopiedLinkExamId(null), 2000);
                          }}
                          className="px-3 py-2 rounded-xl border border-[#d8cdbf] bg-[#fdfbf7] text-xs font-bold text-[#1e1b18] hover:bg-[#f5efe6] transition flex items-center gap-1"
                        >
                          <Copy className="w-3.5 h-3.5 text-[#8c4e28]" />
                          <span>{copiedLinkExamId === ex.id ? 'Copied!' : 'Copy Link'}</span>
                        </button>

                        <button
                          onClick={() => handleDeleteExam(ex.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition"
                          title="Delete Exam"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 7: EXPORT & BACKUP */}
        {activeTab === 'backup' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
                Data Export & Complete Database Backup
              </h2>
              <p className="text-xs text-[#7a6f62]">
                Export student examination results to Microsoft Excel / CSV and download complete JSON backups for safe storage.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* CSV Results Exporter */}
              <div className="p-6 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs space-y-4">
                <FileSpreadsheet className="w-8 h-8 text-[#8c4e28]" />
                <h3 className="font-bold text-base text-[#1e1b18]">Export Student Results to CSV</h3>
                <p className="text-xs text-[#6e6357] leading-relaxed">
                  Download a spreadsheet containing student names, mobile numbers, marks scored, percentages, pass/fail status, and time taken.
                </p>
                <button
                  onClick={() => {
                    const csv = exportAttemptsToCSV(attempts);
                    downloadFile(csv, `RKaria_Exam_Results_${Date.now()}.csv`);
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#8c4e28] hover:bg-[#703b1c] text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Results CSV ({attempts.length} attempts)</span>
                </button>
              </div>

              {/* Full JSON Database Backup */}
              <div className="p-6 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs space-y-4">
                <Download className="w-8 h-8 text-[#8c4e28]" />
                <h3 className="font-bold text-base text-[#1e1b18]">Complete System Backup (JSON)</h3>
                <p className="text-xs text-[#6e6357] leading-relaxed">
                  Download a full backup containing all questions, custom exams, registered students, and examination attempts in a portable JSON file.
                </p>
                <button
                  onClick={() => {
                    const json = exportFullBackupJSON();
                    downloadFile(json, `RKaria_Complete_Backup_${Date.now()}.json`, 'application/json');
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#1e1b18] hover:bg-black text-white text-xs font-bold transition shadow-xs flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Complete Backup JSON</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: FREE HOSTING & DEPLOYMENT GUIDE (GUJARATI & ENGLISH) */}
        {activeTab === 'guide' && (
          <div className="space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-linear-to-br from-[#23201d] via-[#352920] to-[#1e1b18] text-white shadow-xl border border-[#8c4e28]/40">
              <div className="flex items-center gap-2 text-[#c47a46] mb-2 font-bold text-xs uppercase tracking-wider">
                <HelpCircle className="w-4 h-4" />
                <span>R. KARIA PUBLICATION – FREE DEPLOYMENT MANUAL</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold font-serif-legal text-[#fdfbf7]">
                મફત હોસ્ટિંગ અને WhatsApp શેરિંગ માર્ગદર્શિકા
              </h2>
              <p className="text-xs sm:text-sm text-[#d4c6b8] mt-2 leading-relaxed">
                તમારે કોઈપણ ડોમેન નામ ખરીદવાની કે પેઇડ હોસ્ટિંગ લેવાની બિલકુલ જરૂર નથી. નીચે સંપૂર્ણ માર્ગદર્શિકા આપેલી છે.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-[#3e3832]">
              {/* Gujarati Section */}
              <div className="p-6 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs space-y-4">
                <h3 className="text-base font-bold text-[#8c4e28] font-serif-legal border-b border-[#f0e8dc] pb-2">
                  ૧. ૧૦૦% મફત જાહેર URL અને WhatsApp શેરિંગ
                </h3>

                <div className="space-y-3 leading-relaxed">
                  <p>
                    <strong>A. વર્તમાન જાહેર URL:</strong> આ એપ્લિકેશન અત્યારે પણ લાઈવ ક્લાઉડ સર્વર પર કાર્યરત છે. તેનો પબ્લિક URL તમે સીધો વિદ્યાર્થીઓ સાથે શેર કરી શકો છો.
                  </p>
                  <div className="p-3 rounded-xl bg-[#fdfbf7] border border-[#e5dcd1] font-mono text-[11px] text-[#8c4e28] break-all">
                    {window.location.origin}
                  </div>
                  <p>
                    <strong>B. વિદ્યાર્થીઓ માટે સરળ પ્રવેશ:</strong> વિદ્યાર્થીઓને એપ ડાઉનલોડ કરવાની કે OTP નાખવાની જરૂર નથી. લિંક પર ક્લિક કરી સીધું નામ અને મોબાઇલ નંબર નાખીને ૨૦૦ પ્રશ્નોની AIBE પરીક્ષા શરૂ કરી શકે છે.
                  </p>
                  <p>
                    <strong>C. PWA ઇન્સ્ટોલેશન:</strong> વિદ્યાર્થીઓ પોતાના મોબાઇલના બ્રાઉઝરમાં "Add to Home Screen" કરી શકે છે, જેથી મોબાઈલ એપ્લિકેશનની જેમ આઇકોન આવી જશે.
                  </p>
                  <p>
                    <strong>D. ઑફલાઇન સુરક્ષા:</strong> પરીક્ષા દરમિયાન જો નેટવર્ક જતું રહે તો પણ લખેલા જવાબો સ્થાનિક સ્ટોરેજમાં સચવાઈ રહે છે.
                  </p>
                </div>
              </div>

              {/* Vercel & Supabase Free Hosting Instructions */}
              <div className="p-6 rounded-2xl bg-white border border-[#e5dcd1] shadow-xs space-y-4">
                <h3 className="text-base font-bold text-[#8c4e28] font-serif-legal border-b border-[#f0e8dc] pb-2">
                  ૨. Vercel & Supabase ફ્રી ટાયર સેટઅપ ગાઇડ
                </h3>

                <div className="space-y-3 leading-relaxed">
                  <p>
                    જો તમે ભવિષ્યમાં તમારા પોતાના સ્વતંત્ર Vercel અથવા Supabase ખાતા પર આ પ્રોજેક્ટ મુકવા માંગતા હોવ:
                  </p>
                  <ol className="list-decimal pl-4 space-y-1.5">
                    <li>
                      <strong>Vercel Free Tier:</strong> vercel.com પર મફત એકાઉન્ટ બનાવો (Zero Cost).
                    </li>
                    <li>
                      આ પ્રોજેક્ટનો કોડ ગિટહબ (GitHub) પર મૂકો અને Vercel માં "Import Project" પર ક્લિક કરો.
                    </li>
                    <li>
                      Vercel આપમેળે તમને <strong>your-publication.vercel.app</strong> જેવો લાઈવ અને સુરક્ષિત HTTPS પબ્લિક URL ફાળવશે.
                    </li>
                    <li>
                      <strong>ડોમેન ખરીદવાની જરૂર નથી:</strong> vercel.app સબડોમેન સંપૂર્ણપણે મફત અને આજીવન કાર્યરત રહે છે.
                    </li>
                  </ol>

                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-[11px]">
                    <strong>નોંધ:</strong> આ એપ્લિકેશન બ્રાઉઝર સ્ટોરેજ અને ડેટા એક્સપોર્ટ સાથે ૧૦૦% કાર્યરત હોવાથી સુપાબેઝ વગર પણ તમામ ૨૦૦ પ્રશ્નો અને પરિણામો આપમેળે સંચાલિત થાય છે!
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modal: Add / Edit Question */}
      {isEditingQuestion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#fdfbf7] p-6 shadow-2xl border border-[#c47a46]/30">
            <h3 className="text-lg font-bold text-[#1e1b18] font-serif-legal mb-4">
              {questionFormData.id ? 'Edit Question' : 'Add New Question'}
            </h3>

            <form onSubmit={handleSaveQuestionSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Subject</label>
                <select
                  value={questionFormData.subject}
                  onChange={(e) => setQuestionFormData({ ...questionFormData, subject: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                >
                  <option value="Constitutional Law">Constitutional Law</option>
                  <option value="Indian Penal Code / BNS">Indian Penal Code / BNS</option>
                  <option value="Criminal Procedure Code / BNSS">Criminal Procedure Code / BNSS</option>
                  <option value="Indian Evidence Act / BSA">Indian Evidence Act / BSA</option>
                  <option value="Code of Civil Procedure (CPC)">Code of Civil Procedure (CPC)</option>
                  <option value="Law of Contract & Specific Relief">Law of Contract & Specific Relief</option>
                  <option value="Family Law (Hindu & Muslim)">Family Law (Hindu & Muslim)</option>
                  <option value="Arbitration & ADR">Arbitration & ADR</option>
                  <option value="Professional Ethics & Bar Council Rules">Professional Ethics & BCI</option>
                  <option value="Public Interest Litigation (PIL)">Public Interest Litigation (PIL)</option>
                  <option value="Company Law">Company Law</option>
                  <option value="Environmental & Cyber Law">Environmental & Cyber Law</option>
                  <option value="Administrative Law & Tort">Administrative Law & Tort</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Question Text (English) *</label>
                <textarea
                  required
                  rows={2}
                  value={questionFormData.questionText || ''}
                  onChange={(e) => setQuestionFormData({ ...questionFormData, questionText: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  placeholder="Enter the question text in English..."
                />
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Question Text (Gujarati - વૈકલ્પિક)</label>
                <textarea
                  rows={2}
                  value={questionFormData.questionTextGu || ''}
                  onChange={(e) => setQuestionFormData({ ...questionFormData, questionTextGu: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  placeholder="ગુજરાતીમાં પ્રશ્ન લખો..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Option A *</label>
                  <input
                    type="text"
                    required
                    value={questionFormData.optionA || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, optionA: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Option B *</label>
                  <input
                    type="text"
                    required
                    value={questionFormData.optionB || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, optionB: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Option C *</label>
                  <input
                    type="text"
                    required
                    value={questionFormData.optionC || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, optionC: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Option D *</label>
                  <input
                    type="text"
                    required
                    value={questionFormData.optionD || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, optionD: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Correct Answer *</label>
                <div className="flex gap-4">
                  {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                    <label key={opt} className="flex items-center gap-1.5 cursor-pointer font-bold">
                      <input
                        type="radio"
                        name="correctAnswer"
                        value={opt}
                        checked={questionFormData.correctAnswer === opt}
                        onChange={(e) => setQuestionFormData({ ...questionFormData, correctAnswer: opt })}
                      />
                      <span>Option {opt}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Detailed Explanation (English) *</label>
                <textarea
                  required
                  rows={2}
                  value={questionFormData.explanation || ''}
                  onChange={(e) => setQuestionFormData({ ...questionFormData, explanation: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  placeholder="Provide legal reasoning and statutory reference..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Relevant Legal Section</label>
                  <input
                    type="text"
                    value={questionFormData.legalSection || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, legalSection: e.target.value })}
                    placeholder="e.g. Article 21 / Section 300 IPC"
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Landmark Case Law</label>
                  <input
                    type="text"
                    value={questionFormData.caseLaw || ''}
                    onChange={(e) => setQuestionFormData({ ...questionFormData, caseLaw: e.target.value })}
                    placeholder="e.g. Maneka Gandhi v. Union of India (1978)"
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#e5dcd1]">
                <button
                  type="button"
                  onClick={() => setIsEditingQuestion(false)}
                  className="px-4 py-2 rounded-xl border border-[#d8cdbf] bg-white font-bold text-[#6e6357]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#8c4e28] text-white font-bold hover:bg-[#723e1e]"
                >
                  Save Question
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Create / Edit Exam */}
      {isEditingExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#fdfbf7] p-6 shadow-2xl border border-[#c47a46]/30">
            <h3 className="text-lg font-bold text-[#1e1b18] font-serif-legal mb-4">
              {examFormData.id ? 'Edit Examination' : 'Create New Examination'}
            </h3>

            <form onSubmit={handleSaveExamSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Examination Title *</label>
                <input
                  type="text"
                  required
                  value={examFormData.title || ''}
                  onChange={(e) => setExamFormData({ ...examFormData, title: e.target.value })}
                  placeholder="e.g. AIBE Online Mock Examination (200 Questions)"
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Category</label>
                <select
                  value={examFormData.category}
                  onChange={(e) => setExamFormData({ ...examFormData, category: e.target.value as any })}
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                >
                  <option value="AIBE Mock Test">AIBE Mock Test (200 Questions)</option>
                  <option value="Subject-Wise MCQ Test">Subject-Wise MCQ Test</option>
                  <option value="Practice Examination">Practice Examination</option>
                </select>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Questions</label>
                  <input
                    type="number"
                    value={examFormData.totalQuestions || 200}
                    onChange={(e) => setExamFormData({ ...examFormData, totalQuestions: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Duration (Mins)</label>
                  <input
                    type="number"
                    value={examFormData.durationMinutes || 180}
                    onChange={(e) => setExamFormData({ ...examFormData, durationMinutes: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#3a332a] mb-1">Total Marks</label>
                  <input
                    type="number"
                    value={examFormData.totalMarks || 200}
                    onChange={(e) => setExamFormData({ ...examFormData, totalMarks: Number(e.target.value) })}
                    className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#3a332a] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={examFormData.description || ''}
                  onChange={(e) => setExamFormData({ ...examFormData, description: e.target.value })}
                  placeholder="Details for students..."
                  className="w-full p-2.5 rounded-xl border border-[#d6c7b6] bg-white"
                />
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer font-bold">
                  <input
                    type="checkbox"
                    checked={examFormData.isPublished}
                    onChange={(e) => setExamFormData({ ...examFormData, isPublished: e.target.checked })}
                  />
                  <span>Publish Examination Immediately</span>
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-[#e5dcd1]">
                <button
                  type="button"
                  onClick={() => setIsEditingExam(false)}
                  className="px-4 py-2 rounded-xl border border-[#d8cdbf] bg-white font-bold text-[#6e6357]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#8c4e28] text-white font-bold hover:bg-[#723e1e]"
                >
                  Save Examination
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
