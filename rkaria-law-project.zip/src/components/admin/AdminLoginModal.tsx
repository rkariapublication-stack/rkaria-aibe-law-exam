import React, { useState } from 'react';
import { Shield, Lock, User, X, KeyRound, AlertCircle } from 'lucide-react';
import { verifyAdminCredentials } from '../../services/storage';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export const AdminLoginModal: React.FC<Props> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('rkaria@aibe2026');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const success = verifyAdminCredentials(username, password);
    if (success) {
      onLoginSuccess();
      onClose();
    } else {
      setError('Invalid Administrator credentials. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-[#fdfbf7] p-6 sm:p-8 shadow-2xl border border-[#c47a46]/30 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rounded-full p-1.5 text-[#8c4e28]/60 hover:text-[#8c4e28] hover:bg-[#8c4e28]/10 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-[#1e1b18] border border-[#8c4e28]/40 p-2 shadow-md mb-3 flex items-center justify-center">
            <Shield className="w-7 h-7 text-[#c47a46]" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#1e1b18] font-serif-legal">
            Admin Control Portal
          </h2>
          <p className="text-xs font-semibold text-[#8c4e28] tracking-wider uppercase mt-0.5">
            R. KARIA PUBLICATION
          </p>
          <p className="text-xs text-[#7a6f62] mt-1.5">
            Secure login for publication directors and exam controllers.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#3a332a] mb-1.5 uppercase tracking-wide">
              Username or Email
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8c4e28]">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#d6c7b6] bg-white text-sm text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28] focus:border-transparent transition"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#3a332a] mb-1.5 uppercase tracking-wide">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#8c4e28]">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#d6c7b6] bg-white text-sm text-[#1e1b18] focus:outline-hidden focus:ring-2 focus:ring-[#8c4e28] focus:border-transparent transition"
              />
            </div>
          </div>

          {/* Quick credential helper for the publication owner */}
          <div className="p-3 rounded-xl bg-[#f5efe6] border border-[#e5d9c9] text-[11px] text-[#6e6357]">
            <p className="font-bold text-[#8c4e28] flex items-center gap-1 mb-1">
              <KeyRound className="w-3.5 h-3.5" />
              <span>Default Publication Credentials:</span>
            </p>
            <p>
              Username: <code className="bg-white px-1.5 py-0.5 rounded border border-[#d8ccbe] font-mono">admin</code>
            </p>
            <p className="mt-1">
              Password: <code className="bg-white px-1.5 py-0.5 rounded border border-[#d8ccbe] font-mono">rkaria@aibe2026</code>
            </p>
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#8c4e28] hover:bg-[#703b1c] text-white py-3 font-bold text-sm shadow-md transition"
          >
            <Shield className="w-4 h-4" />
            <span>Login to Admin Portal</span>
          </button>
        </form>
      </div>
    </div>
  );
};
