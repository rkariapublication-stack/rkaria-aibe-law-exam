import React, { useState } from 'react';
import { Download, Shield, User, LogOut, Globe, Sparkles } from 'lucide-react';
import { Student } from '../../types';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { PWAInstallModal } from './PWAInstallModal';

interface Props {
  currentStudent: Student | null;
  onOpenStudentModal: () => void;
  onLogoutStudent: () => void;
  onOpenAdmin: () => void;
  onGoHome: () => void;
  language: 'en' | 'gu';
  onToggleLanguage: () => void;
}

export const Header: React.FC<Props> = ({
  currentStudent,
  onOpenStudentModal,
  onLogoutStudent,
  onOpenAdmin,
  onGoHome,
  language,
  onToggleLanguage,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showInstallModal, setShowInstallModal] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#fdfbf7]/95 backdrop-blur-md border-b border-[#e5dcd1] shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Logo and Brand Title */}
            <div
              onClick={onGoHome}
              className="flex items-center gap-2.5 sm:gap-3.5 cursor-pointer group select-none"
            >
              <div className="relative w-10 h-10 sm:w-13 sm:h-13 rounded-xl overflow-hidden border border-[#8c4e28]/25 shadow-sm bg-[#1e1b18] flex items-center justify-center p-0.5 group-hover:border-[#8c4e28] transition">
                <img
                  src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                  alt="R. Karia Publication Official Logo"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                  }}
                />
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-base sm:text-xl font-bold tracking-tight text-[#1e1b18] font-serif-legal">
                    R. KARIA PUBLICATION
                  </h1>
                  <span className="hidden sm:inline-block text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-[#8c4e28]/10 text-[#8c4e28] uppercase tracking-wider">
                    Official
                  </span>
                </div>
                <p className="text-[10px] sm:text-xs font-semibold text-[#8c4e28] tracking-wider uppercase">
                  {language === 'gu' ? 'લો સ્ટુડન્ટ પેપર સોલ્યુશન' : 'LAW STUDENT PAPER SOLUTION'}
                </p>
              </div>
            </div>

            {/* Right Nav Actions */}
            <div className="flex items-center gap-1.5 sm:gap-3">
              {/* Language Switcher */}
              <button
                onClick={onToggleLanguage}
                title="Switch Language (English / ગુજરાતી)"
                className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-[#d9cdbf] bg-white text-[#5c5042] hover:bg-[#f5efe6] transition"
              >
                <Globe className="w-3.5 h-3.5 text-[#8c4e28]" />
                <span className="hidden xs:inline">{language === 'gu' ? 'ગુજરાતી' : 'English'}</span>
                <span className="text-[10px] px-1 rounded bg-[#8c4e28]/10 text-[#8c4e28]">
                  {language === 'gu' ? 'EN' : 'ગુ'}
                </span>
              </button>

              {/* Install PWA Button */}
              {!isInstalled && (
                <button
                  onClick={() => {
                    if (isInstallable) {
                      install();
                    } else {
                      setShowInstallModal(true);
                    }
                  }}
                  className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-[#8c4e28] hover:bg-[#703b1c] text-white text-xs font-semibold shadow-xs transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{language === 'gu' ? 'એપ ઇન્સ્ટોલ કરો' : 'Install App'}</span>
                </button>
              )}

              {/* Student Profile / Register */}
              {currentStudent ? (
                <div className="flex items-center gap-1.5 pl-1">
                  <div
                    onClick={onGoHome}
                    className="cursor-pointer text-right hidden md:block"
                  >
                    <p className="text-xs font-bold text-[#1e1b18] truncate max-w-[130px]">
                      {currentStudent.fullName}
                    </p>
                    <p className="text-[10px] text-[#7a6f62]">
                      +91 {currentStudent.mobileNumber}
                    </p>
                  </div>
                  <button
                    onClick={onLogoutStudent}
                    title="Change Student / Log Out"
                    className="p-1.5 text-xs text-[#8c4e28] hover:bg-[#8c4e28]/10 rounded-lg transition"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={onOpenStudentModal}
                  className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#23201d] text-[#f7f3ea] hover:bg-black transition"
                >
                  <User className="w-3.5 h-3.5 text-[#c47a46]" />
                  <span>{language === 'gu' ? 'વિદ્યાર્થી પ્રવેશ' : 'Student Login'}</span>
                </button>
              )}

              {/* Admin Portal Button */}
              <button
                onClick={onOpenAdmin}
                title="Publication Admin Portal"
                className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg border border-[#8c4e28]/30 bg-white hover:bg-[#8c4e28]/5 text-[#8c4e28] text-xs font-bold transition ml-0.5"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{language === 'gu' ? 'એડમિન' : 'Admin'}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* PWA Install Guide Modal */}
      <PWAInstallModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
        isIOS={isIOS}
        onInstallClick={install}
      />
    </>
  );
};
