import React from 'react';
import { Download, Share, PlusSquare, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  isIOS: boolean;
  onInstallClick?: () => void;
}

export const PWAInstallModal: React.FC<Props> = ({ isOpen, onClose, isIOS, onInstallClick }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl bg-[#fdfbf7] p-6 shadow-2xl border border-[#c47a46]/20">
        <div className="flex items-center justify-between pb-3 border-b border-[#e2d8cb]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#8c4e28]/30 bg-[#23201d] flex items-center justify-center p-1">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                alt="R. Karia Publication"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
            </div>
            <div>
              <h3 className="font-bold text-[#1e1b18] text-base font-serif-legal">Install R. Karia App</h3>
              <p className="text-xs text-[#8c4e28] font-medium">Quick Access on Mobile Home Screen</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1 text-[#8c4e28]/60 hover:text-[#8c4e28] hover:bg-[#8c4e28]/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-5 space-y-4 text-sm text-[#3e3832]">
          {isIOS ? (
            <div className="space-y-3">
              <p className="text-xs text-[#5c544c]">
                Install on your <strong>iPhone</strong> or <strong>iPad</strong> for full-screen examination mode:
              </p>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-[#e2d8cb]">
                <div className="w-7 h-7 rounded-lg bg-[#8c4e28]/10 text-[#8c4e28] flex items-center justify-center shrink-0">
                  <Share className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-semibold text-xs text-[#1e1b18]">Step 1: Tap Share</p>
                  <p className="text-xs text-[#5c544c]">Tap the Share icon at the bottom of Safari.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-xl bg-white border border-[#e2d8cb]">
                <div className="w-7 h-7 rounded-lg bg-[#8c4e28]/10 text-[#8c4e28] flex items-center justify-center shrink-0">
                  <PlusSquare className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-semibold text-xs text-[#1e1b18]">Step 2: Add to Home Screen</p>
                  <p className="text-xs text-[#5c544c]">Scroll down and select "Add to Home Screen".</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-[#5c544c]">
                Install the application directly on your <strong>Android phone</strong> or <strong>Computer</strong> for fast, offline-ready bar examination practice.
              </p>
              <button
                onClick={() => {
                  if (onInstallClick) onInstallClick();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-[#8c4e28] hover:bg-[#723e1e] text-white py-3 font-semibold shadow-md transition"
              >
                <Download className="w-4 h-4" />
                Add to Home Screen Now
              </button>
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full rounded-xl bg-[#e8e0d4] py-2 text-xs font-semibold text-[#5c544c] hover:bg-[#ded4c4] transition"
        >
          Close
        </button>
      </div>
    </div>
  );
};
