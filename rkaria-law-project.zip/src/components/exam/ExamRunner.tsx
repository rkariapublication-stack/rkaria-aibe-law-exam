import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  RotateCcw,
  Send,
  LayoutGrid,
  AlertTriangle,
  Globe,
  Sparkles,
  Wifi,
} from 'lucide-react';
import { Exam, ExamAttempt, ExamSessionState, Question, Student, StudentAnswer } from '../../types';
import {
  getAllQuestions,
  getActiveExamSession,
  saveActiveExamSession,
  clearActiveExamSession,
  submitExamAttempt,
} from '../../services/storage';
import { QuestionPalette } from './QuestionPalette';

interface Props {
  exam: Exam;
  student: Student;
  onFinishExam: (attempt: ExamAttempt) => void;
  onExitExam: () => void;
  language: 'en' | 'gu';
  onToggleLanguage: () => void;
}

export const ExamRunner: React.FC<Props> = ({
  exam,
  student,
  onFinishExam,
  onExitExam,
  language,
  onToggleLanguage,
}) => {
  // Load questions for this exam
  const allQuestions = getAllQuestions();
  const questionMap = new Map(allQuestions.map((q) => [q.id, q]));
  const questions: Question[] = exam.questionIds
    .map((id) => questionMap.get(id))
    .filter((q): q is Question => !!q);

  const totalQuestions = questions.length;

  // Initialize or restore session
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, StudentAnswer>>({});
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState<number>(exam.durationMinutes * 60);
  const [startedAt, setStartedAt] = useState<string>(new Date().toISOString());
  const [isPaletteOpen, setIsPaletteOpen] = useState<boolean>(false);
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Restore session from localStorage if user refreshed or navigated back
  useEffect(() => {
    const saved = getActiveExamSession();
    if (saved && saved.examId === exam.id && saved.studentId === student.id) {
      setAnswers(saved.answers || {});
      setCurrentIndex(saved.currentQuestionIndex || 0);
      setStartedAt(saved.startedAt || new Date().toISOString());
      if (saved.timeRemainingSeconds > 0) {
        setTimeRemainingSeconds(saved.timeRemainingSeconds);
      }
    }
  }, [exam.id, student.id]);

  // Auto-save session on changes
  useEffect(() => {
    const session: ExamSessionState = {
      attemptId: `in-prog-${exam.id}`,
      examId: exam.id,
      studentId: student.id,
      startedAt,
      timeRemainingSeconds,
      answers,
      currentQuestionIndex: currentIndex,
      language,
    };
    saveActiveExamSession(session);
  }, [answers, currentIndex, timeRemainingSeconds, exam.id, student.id, startedAt, language]);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Auto submit when time reaches zero
          handleFinalSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [answers]);

  // Final submission handler
  const handleFinalSubmit = () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    const timeTaken = exam.durationMinutes * 60 - timeRemainingSeconds;
    const attempt = submitExamAttempt({
      student,
      exam,
      answers,
      timeTakenSeconds: Math.max(1, timeTaken),
      startedAt,
    });

    clearActiveExamSession();
    onFinishExam(attempt);
  };

  // Format timer
  const hours = Math.floor(timeRemainingSeconds / 3600);
  const minutes = Math.floor((timeRemainingSeconds % 3600) / 60);
  const seconds = timeRemainingSeconds % 60;
  const timeString = `${hours > 0 ? `${hours}:` : ''}${String(minutes).padStart(2, '0')}:${String(
    seconds
  ).padStart(2, '0')}`;
  const isTimeCritical = timeRemainingSeconds < 900; // < 15 mins

  // Current question data
  const currentQuestion = questions[currentIndex];
  const currentAnswer = currentQuestion ? answers[currentQuestion.id] : undefined;
  const selectedOption = currentAnswer?.selectedOption || null;
  const isMarkedForReview = currentAnswer?.isMarkedForReview || false;

  // Option selection handler
  const handleSelectOption = (opt: 'A' | 'B' | 'C' | 'D') => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        questionId: currentQuestion.id,
        selectedOption: opt,
        isMarkedForReview: prev[currentQuestion.id]?.isMarkedForReview || false,
      },
    }));
  };

  // Clear answer handler
  const handleClearResponse = () => {
    if (!currentQuestion) return;
    setAnswers((prev) => {
      const updated = { ...prev };
      if (updated[currentQuestion.id]) {
        updated[currentQuestion.id] = {
          ...updated[currentQuestion.id],
          selectedOption: null,
        };
      }
      return updated;
    });
  };

  // Toggle mark for review handler
  const handleToggleReview = () => {
    if (!currentQuestion) return;
    setAnswers((prev) => {
      const current = prev[currentQuestion.id];
      return {
        ...prev,
        [currentQuestion.id]: {
          questionId: currentQuestion.id,
          selectedOption: current?.selectedOption || null,
          isMarkedForReview: !current?.isMarkedForReview,
        },
      };
    });
  };

  // Summary counts for submit modal
  const answeredCount = Object.values(answers).filter((a) => a.selectedOption).length;
  const unansweredCount = totalQuestions - answeredCount;
  const reviewCount = Object.values(answers).filter((a) => a.isMarkedForReview).length;

  if (!currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <p className="text-lg font-bold text-red-600">No questions available for this examination.</p>
          <button
            onClick={onExitExam}
            className="mt-4 px-4 py-2 bg-[#8c4e28] text-white rounded-xl text-sm font-bold"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const questionText =
    language === 'gu' && currentQuestion.questionTextGu
      ? currentQuestion.questionTextGu
      : currentQuestion.questionText;

  const options: Array<{ key: 'A' | 'B' | 'C' | 'D'; textEn: string; textGu?: string }> = [
    { key: 'A', textEn: currentQuestion.optionA, textGu: currentQuestion.optionAGu },
    { key: 'B', textEn: currentQuestion.optionB, textGu: currentQuestion.optionBGu },
    { key: 'C', textEn: currentQuestion.optionC, textGu: currentQuestion.optionCGu },
    { key: 'D', textEn: currentQuestion.optionD, textGu: currentQuestion.optionDGu },
  ];

  return (
    <div className="min-h-screen bg-[#fdfbf7] flex flex-col select-none">
      {/* Top Fixed Examination Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#e5dcd1] shadow-xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
          {/* Brand & Exam Title */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl overflow-hidden border border-[#8c4e28]/30 bg-[#1e1b18] shrink-0 p-0.5 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                alt="Logo"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
            </div>
            <div className="min-w-0">
              <h2 className="text-xs sm:text-sm font-bold text-[#1e1b18] truncate font-serif-legal">
                {language === 'gu' && exam.titleGu ? exam.titleGu : exam.title}
              </h2>
              <p className="text-[10px] text-[#8c4e28] font-semibold truncate">
                Candidate: {student.fullName} (+91 {student.mobileNumber})
              </p>
            </div>
          </div>

          {/* Right Controls: Timer, Palette, Submit */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Language Switch */}
            <button
              onClick={onToggleLanguage}
              className="text-[11px] font-bold px-2 py-1.5 rounded-lg border border-[#d9cdbf] bg-[#fdfbf7] text-[#5c5042] hover:bg-[#f5efe6] transition flex items-center gap-1"
            >
              <Globe className="w-3.5 h-3.5 text-[#8c4e28]" />
              <span className="hidden xs:inline">{language === 'gu' ? 'ગુજરાતી' : 'EN'}</span>
            </button>

            {/* Countdown Timer */}
            <div
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs sm:text-sm font-bold tracking-wider font-mono transition ${
                isTimeCritical
                  ? 'bg-red-50 border-red-300 text-red-700 animate-pulse'
                  : 'bg-[#23201d] border-black text-[#fdfbf7]'
              }`}
            >
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#c47a46]" />
              <span>{timeString}</span>
            </div>

            {/* Question Palette Trigger */}
            <button
              onClick={() => setIsPaletteOpen(true)}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-white border border-[#d9cdbf] text-xs font-bold text-[#1e1b18] hover:bg-[#f5efe6] transition"
            >
              <LayoutGrid className="w-4 h-4 text-[#8c4e28]" />
              <span className="hidden sm:inline">
                {currentIndex + 1} / {totalQuestions}
              </span>
            </button>

            {/* Submit Button */}
            <button
              onClick={() => setShowSubmitModal(true)}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold shadow-xs transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{language === 'gu' ? 'સબમિટ' : 'Submit'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Examination Question Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-between">
        <div className="space-y-6">
          {/* Question Header & Tags */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#e5dcd1]">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl bg-[#8c4e28] text-white text-xs font-bold font-mono">
                {language === 'gu'
                  ? `પ્રશ્ન ${currentIndex + 1} / ${totalQuestions}`
                  : `Question ${currentIndex + 1} of ${totalQuestions}`}
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-[#8c4e28]/10 text-[#8c4e28] text-xs font-semibold">
                {currentQuestion.subject}
              </span>
            </div>

            {isMarkedForReview && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-100 text-amber-800 text-xs font-bold">
                <Flag className="w-3.5 h-3.5 fill-current" />
                <span>{language === 'gu' ? 'રિવ્યુ માટે ચિહ્નિત' : 'Marked for Review'}</span>
              </span>
            )}
          </div>

          {/* Question Text */}
          <div className="bg-white rounded-2xl p-5 sm:p-7 border border-[#e8dfd3] shadow-xs">
            <h3 className="text-base sm:text-lg font-semibold text-[#1e1b18] leading-relaxed">
              {questionText}
            </h3>

            {/* Secondary language display if dual language requested */}
            {language === 'gu' && currentQuestion.questionText && (
              <p className="mt-2 text-xs text-[#7a6f62] italic border-t border-[#f0e8dc] pt-2">
                En: {currentQuestion.questionText}
              </p>
            )}
            {language === 'en' && currentQuestion.questionTextGu && (
              <p className="mt-2 text-xs text-[#7a6f62] font-gujarati border-t border-[#f0e8dc] pt-2">
                ગુ: {currentQuestion.questionTextGu}
              </p>
            )}
          </div>

          {/* Options List */}
          <div className="space-y-3">
            {options.map((opt) => {
              const isSelected = selectedOption === opt.key;
              const text =
                language === 'gu' && opt.textGu ? opt.textGu : opt.textEn;

              return (
                <div
                  key={opt.key}
                  onClick={() => handleSelectOption(opt.key)}
                  className={`flex items-start gap-3.5 p-4 rounded-2xl border-2 cursor-pointer transition select-none ${
                    isSelected
                      ? 'bg-[#8c4e28]/5 border-[#8c4e28] shadow-xs'
                      : 'bg-white border-[#e8dfd3] hover:border-[#c47a46]/50 hover:bg-[#fdfbf7]'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition ${
                      isSelected
                        ? 'bg-[#8c4e28] text-white shadow-xs'
                        : 'bg-[#f3ede3] text-[#554a3e]'
                    }`}
                  >
                    {opt.key}
                  </div>
                  <div className="flex-1 pt-0.5">
                    <p
                      className={`text-sm sm:text-base leading-relaxed ${
                        isSelected ? 'font-semibold text-[#1e1b18]' : 'text-[#3e3832]'
                      }`}
                    >
                      {text}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Actions Bar */}
        <div className="mt-8 pt-4 border-t border-[#e5dcd1] flex flex-wrap items-center justify-between gap-3">
          {/* Left Actions: Review & Clear */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleReview}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition border ${
                isMarkedForReview
                  ? 'bg-amber-500 border-amber-500 text-white'
                  : 'bg-white border-[#d8cdbf] text-[#6e6357] hover:bg-[#f5efe6]'
              }`}
            >
              <Flag className="w-3.5 h-3.5 fill-current" />
              <span>
                {isMarkedForReview
                  ? language === 'gu'
                    ? 'ચિહ્ન હટાવો'
                    : 'Unmark Review'
                  : language === 'gu'
                  ? 'રિવ્યુ માટે માર્ક કરો'
                  : 'Mark for Review'}
              </span>
            </button>

            {selectedOption && (
              <button
                onClick={handleClearResponse}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{language === 'gu' ? 'જવાબ સાફ કરો' : 'Clear'}</span>
              </button>
            )}
          </div>

          {/* Right Actions: Previous & Next */}
          <div className="flex items-center gap-2">
            <button
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-white border border-[#d8cdbf] text-xs font-bold text-[#1e1b18] hover:bg-[#f5efe6] transition disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>{language === 'gu' ? 'પાછળ' : 'Previous'}</span>
            </button>

            <button
              onClick={() => {
                if (currentIndex < totalQuestions - 1) {
                  setCurrentIndex((prev) => prev + 1);
                } else {
                  setShowSubmitModal(true);
                }
              }}
              className="flex items-center gap-1 px-5 py-2 rounded-xl bg-[#8c4e28] hover:bg-[#723e1e] text-white text-xs font-bold shadow-xs transition"
            >
              <span>
                {currentIndex === totalQuestions - 1
                  ? language === 'gu'
                    ? 'સમીક્ષા અને સબમિટ'
                    : 'Review & Submit'
                  : language === 'gu'
                  ? 'આગળ'
                  : 'Save & Next'}
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </main>

      {/* Question Palette Sidebar */}
      <QuestionPalette
        totalQuestions={totalQuestions}
        questionIds={exam.questionIds}
        currentIndex={currentIndex}
        answers={answers}
        onSelectQuestion={(idx) => setCurrentIndex(idx)}
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        language={language}
      />

      {/* Submit Confirmation Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#fdfbf7] p-6 shadow-2xl border border-[#c47a46]/30">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-[#1e1b18] text-base font-serif-legal">
                  {language === 'gu' ? 'પરીક્ષા સબમિટ કરવી છે?' : 'Confirm Exam Submission'}
                </h3>
                <p className="text-xs text-[#7a6f62]">
                  {language === 'gu'
                    ? 'સબમિટ કર્યા પછી ઉત્તરો બદલી શકાશે નહીં.'
                    : 'You will not be able to change answers after final submission.'}
                </p>
              </div>
            </div>

            {/* Summary Grid */}
            <div className="my-4 p-4 rounded-xl bg-white border border-[#e5dcd1] grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-800">
                <p className="font-semibold text-[10px] uppercase">
                  {language === 'gu' ? 'જવાબ આપેલ' : 'Answered'}
                </p>
                <p className="text-lg font-bold">{answeredCount}</p>
              </div>
              <div className="p-2 rounded-lg bg-gray-50 text-gray-700">
                <p className="font-semibold text-[10px] uppercase">
                  {language === 'gu' ? 'બાકી' : 'Unanswered'}
                </p>
                <p className="text-lg font-bold">{unansweredCount}</p>
              </div>
              <div className="p-2 rounded-lg bg-amber-50 text-amber-800">
                <p className="font-semibold text-[10px] uppercase">
                  {language === 'gu' ? 'રિવ્યુ માટે' : 'Review'}
                </p>
                <p className="text-lg font-bold">{reviewCount}</p>
              </div>
            </div>

            <div className="flex gap-2.5 mt-6">
              <button
                onClick={() => setShowSubmitModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-[#d8cdbf] bg-white text-xs font-bold text-[#5c5042] hover:bg-[#f5efe6] transition"
              >
                {language === 'gu' ? 'પરીક્ષા ચાલુ રાખો' : 'Resume Exam'}
              </button>
              <button
                disabled={isSubmitting}
                onClick={handleFinalSubmit}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md transition disabled:opacity-50"
              >
                {isSubmitting
                  ? language === 'gu'
                    ? 'ગણતરી ચાલુ છે...'
                    : 'Grading...'
                  : language === 'gu'
                  ? 'હા, સબમિટ કરો'
                  : 'Yes, Submit Now'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
