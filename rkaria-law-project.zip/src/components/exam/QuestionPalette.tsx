import React, { useState } from 'react';
import { CheckCircle2, Bookmark, Circle, Eye, X } from 'lucide-react';
import { StudentAnswer } from '../../types';

interface Props {
  totalQuestions: number;
  questionIds: string[];
  currentIndex: number;
  answers: Record<string, StudentAnswer>;
  onSelectQuestion: (index: number) => void;
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'gu';
}

export const QuestionPalette: React.FC<Props> = ({
  totalQuestions,
  questionIds,
  currentIndex,
  answers,
  onSelectQuestion,
  isOpen,
  onClose,
  language,
}) => {
  const [filter, setFilter] = useState<'all' | 'answered' | 'unanswered' | 'review'>('all');

  // Count metrics
  let answeredCount = 0;
  let reviewCount = 0;

  questionIds.forEach((id) => {
    const ans = answers[id];
    if (ans?.selectedOption) answeredCount++;
    if (ans?.isMarkedForReview) reviewCount++;
  });

  const unansweredCount = totalQuestions - answeredCount;

  return (
    <div
      className={`fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-[#fdfbf7] shadow-2xl border-l border-[#e5dcd1] transform transition-transform duration-300 ease-in-out flex flex-col ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      {/* Palette Header */}
      <div className="p-4 border-b border-[#e5dcd1] flex items-center justify-between bg-white">
        <div>
          <h3 className="font-bold text-[#1e1b18] text-sm sm:text-base font-serif-legal">
            {language === 'gu' ? 'પ્રશ્ન નેવિગેશન પેનલ' : 'Question Navigation Panel'}
          </h3>
          <p className="text-xs text-[#7a6f62]">
            {language === 'gu' ? `કુલ ${totalQuestions} પ્રશ્નો` : `Total ${totalQuestions} Questions`}
          </p>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-[#8c4e28] hover:bg-[#8c4e28]/10 transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Summary Legend */}
      <div className="p-4 bg-[#f8f4ec] border-b border-[#e5dcd1] grid grid-cols-2 gap-2 text-xs">
        <div className="flex items-center gap-2 p-2 rounded-lg bg-white border border-[#e5dcd1]">
          <span className="w-4 h-4 rounded-full bg-emerald-600 text-white text-[10px] flex items-center justify-center font-bold">
            ✓
          </span>
          <span className="text-[#332c24] font-medium">
            {language === 'gu' ? 'જવાબ આપેલ: ' : 'Answered: '}
            <strong className="text-emerald-700">{answeredCount}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 p-2 rounded-lg bg-white border border-[#e5dcd1]">
          <span className="w-4 h-4 rounded-full bg-[#ded6ca] text-[#554b3f] text-[10px] flex items-center justify-center font-bold">
            •
          </span>
          <span className="text-[#332c24] font-medium">
            {language === 'gu' ? 'બાકી: ' : 'Unanswered: '}
            <strong className="text-[#554b3f]">{unansweredCount}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 p-2 rounded-lg bg-white border border-[#e5dcd1]">
          <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
            ★
          </span>
          <span className="text-[#332c24] font-medium">
            {language === 'gu' ? 'રિવ્યુ માટે: ' : 'Marked Review: '}
            <strong className="text-amber-700">{reviewCount}</strong>
          </span>
        </div>

        <div className="flex items-center gap-2 p-2 rounded-lg bg-white border border-[#e5dcd1]">
          <span className="w-4 h-4 rounded-full border-2 border-[#8c4e28] bg-white flex items-center justify-center"></span>
          <span className="text-[#332c24] font-medium">
            {language === 'gu' ? 'હાલનો પ્રશ્ન' : 'Current'}
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-4 py-2 border-b border-[#e5dcd1] flex gap-1 bg-white overflow-x-auto">
        {(['all', 'answered', 'unanswered', 'review'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`px-2.5 py-1 text-xs font-semibold rounded-lg whitespace-nowrap capitalize transition ${
              filter === tab
                ? 'bg-[#8c4e28] text-white shadow-xs'
                : 'bg-transparent text-[#6e6357] hover:bg-[#f5efe6]'
            }`}
          >
            {tab === 'all'
              ? language === 'gu'
                ? `બધા (${totalQuestions})`
                : `All (${totalQuestions})`
              : tab === 'answered'
              ? language === 'gu'
                ? `જવાબ આપેલ (${answeredCount})`
                : `Answered (${answeredCount})`
              : tab === 'unanswered'
              ? language === 'gu'
                ? `બાકી (${unansweredCount})`
                : `Unanswered (${unansweredCount})`
              : language === 'gu'
              ? `રિવ્યુ (${reviewCount})`
              : `Review (${reviewCount})`}
          </button>
        ))}
      </div>

      {/* Question Grid (Pills for all 200 questions) */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-5 sm:grid-cols-6 gap-2">
          {questionIds.map((qId, idx) => {
            const ans = answers[qId];
            const isAnswered = !!ans?.selectedOption;
            const isReview = !!ans?.isMarkedForReview;
            const isCurrent = idx === currentIndex;

            // Apply filter
            if (filter === 'answered' && !isAnswered) return null;
            if (filter === 'unanswered' && isAnswered) return null;
            if (filter === 'review' && !isReview) return null;

            let bgColor = 'bg-white text-[#52483d] border-[#d8cdc0]';
            if (isAnswered) {
              bgColor = 'bg-emerald-600 text-white border-emerald-600 font-bold';
            }
            if (isReview) {
              bgColor = isAnswered
                ? 'bg-amber-600 text-white border-amber-600 font-bold ring-2 ring-amber-400'
                : 'bg-amber-100 text-amber-900 border-amber-400 font-bold';
            }
            if (isCurrent) {
              bgColor += ' ring-2 ring-[#8c4e28] ring-offset-2 scale-105';
            }

            return (
              <button
                key={qId}
                onClick={() => {
                  onSelectQuestion(idx);
                  if (window.innerWidth < 640) onClose();
                }}
                className={`h-10 rounded-xl border text-xs font-semibold flex items-center justify-center transition hover:shadow-xs active:scale-95 ${bgColor}`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>
      </div>

      {/* Palette Footer */}
      <div className="p-3 border-t border-[#e5dcd1] bg-white text-center">
        <button
          onClick={onClose}
          className="w-full py-2 rounded-xl bg-[#8c4e28] text-white text-xs font-bold hover:bg-[#723e1e] transition"
        >
          {language === 'gu' ? 'પેનલ બંધ કરો' : 'Close Panel'}
        </button>
      </div>
    </div>
  );
};
