import React, { useEffect, useState } from 'react';
import {
  Award,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  Share2,
  Printer,
  ArrowLeft,
  Sparkles,
  BookOpen,
  Filter,
  Check,
  X,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExamAttempt, Question } from '../../types';
import { getAllQuestions } from '../../services/storage';

interface Props {
  attempt: ExamAttempt;
  onBackToDashboard: () => void;
  language: 'en' | 'gu';
}

export const ExamResultView: React.FC<Props> = ({ attempt, onBackToDashboard, language }) => {
  const [filter, setFilter] = useState<'all' | 'correct' | 'wrong' | 'unanswered'>('all');
  const allQuestions = getAllQuestions();
  const questionMap = new Map(allQuestions.map((q) => [q.id, q]));

  // Trigger celebratory confetti if passed
  useEffect(() => {
    if (attempt.isPassed) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#c47a46', '#8c4e28', '#10b981', '#fbbf24', '#ffffff'],
      });
    }
  }, [attempt.isPassed]);

  // Format time taken
  const mins = Math.floor(attempt.timeTakenSeconds / 60);
  const secs = attempt.timeTakenSeconds % 60;
  const timeTakenFormatted = `${mins}m ${secs}s`;

  // WhatsApp share result
  const handleShareResultWhatsApp = () => {
    const text = `*R. KARIA PUBLICATION – LAW STUDENT PAPER SOLUTION*
*AIBE EXAMINATION RESULT*

Student: *${attempt.studentName}*
Mobile: +91 ${attempt.studentMobile}
Examination: ${attempt.examTitle}
Date: ${new Date(attempt.submittedAt).toLocaleDateString()}

Total Questions: ${attempt.totalQuestions}
Attempted: ${attempt.attemptedQuestions}
Correct Answers: ${attempt.correctAnswers}
Wrong Answers: ${attempt.wrongAnswers}
Total Marks: *${attempt.totalMarksScored} / ${attempt.maxMarks}*
Percentage: *${attempt.percentage}%*
Result: *${attempt.isPassed ? 'PASSED (AIBE Qualified)' : 'NEEDS REVISION'}*

Official Website: ${window.location.origin}`;

    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handlePrint = () => {
    window.print();
  };

  // Build question review list
  const questionReviews = Object.entries(attempt.answers).map(([qId, ans]) => {
    const q = questionMap.get(qId);
    const selected = ans.selectedOption;
    const isCorrect = q ? selected === q.correctAnswer : false;
    const isUnanswered = !selected;
    return {
      questionId: qId,
      question: q,
      selectedOption: selected,
      correctAnswer: q?.correctAnswer,
      isCorrect,
      isUnanswered,
    };
  });

  const filteredReviews = questionReviews.filter((item) => {
    if (filter === 'correct') return item.isCorrect;
    if (filter === 'wrong') return !item.isCorrect && !item.isUnanswered;
    if (filter === 'unanswered') return item.isUnanswered;
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-8">
      {/* Back button */}
      <div className="no-print flex items-center justify-between">
        <button
          onClick={onBackToDashboard}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#8c4e28] hover:text-[#703b1c] transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{language === 'gu' ? 'ડેશબોર્ડ પર પાછા જાઓ' : 'Back to Dashboard'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareResultWhatsApp}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{language === 'gu' ? 'WhatsApp પર શેર કરો' : 'Share on WhatsApp'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#d8cdbf] text-[#1e1b18] text-xs font-bold hover:bg-[#f5efe6] transition"
          >
            <Printer className="w-3.5 h-3.5 text-[#8c4e28]" />
            <span>{language === 'gu' ? 'પ્રિન્ટ / PDF ડાઉનલોડ' : 'Print / Download PDF'}</span>
          </button>
        </div>
      </div>

      {/* Official Scorecard Banner */}
      <div className="rounded-3xl bg-linear-to-b from-white to-[#fcfaf6] border-2 border-[#8c4e28]/25 p-6 sm:p-8 shadow-md relative overflow-hidden">
        {/* Certificate Watermark Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#e8dfd3]">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl overflow-hidden border border-[#8c4e28]/30 bg-[#1e1b18] shrink-0 p-1 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                alt="R. Karia Publication"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold font-serif-legal text-[#1e1b18]">
                R. KARIA PUBLICATION
              </h2>
              <p className="text-xs font-bold text-[#8c4e28] tracking-widest uppercase">
                LAW STUDENT PAPER SOLUTION – AIBE SCORECARD
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <span
              className={`inline-block px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider ${
                attempt.isPassed
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}
            >
              {attempt.isPassed ? 'AIBE QUALIFIED (PASS)' : 'NEEDS REVISION (FAIL)'}
            </span>
            <p className="text-[11px] text-[#7a6f62] mt-1 flex sm:justify-end items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {new Date(attempt.submittedAt).toLocaleString()}
            </p>
          </div>
        </div>

        {/* Candidate & Exam Metadata */}
        <div className="my-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          <div className="p-3 rounded-xl bg-[#fdfbf7] border border-[#eee5d9]">
            <p className="text-[#7a6f62] uppercase font-bold text-[10px]">
              {language === 'gu' ? 'વિદ્યાર્થીનું નામ' : 'Student Name'}
            </p>
            <p className="text-sm font-extrabold text-[#1e1b18] mt-0.5">{attempt.studentName}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#fdfbf7] border border-[#eee5d9]">
            <p className="text-[#7a6f62] uppercase font-bold text-[10px]">
              {language === 'gu' ? 'મોબાઇલ નંબર' : 'Mobile Number'}
            </p>
            <p className="text-sm font-extrabold text-[#1e1b18] mt-0.5 font-mono">
              +91 {attempt.studentMobile}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-[#fdfbf7] border border-[#eee5d9]">
            <p className="text-[#7a6f62] uppercase font-bold text-[10px]">
              {language === 'gu' ? 'પરીક્ષાનું નામ' : 'Examination'}
            </p>
            <p className="text-sm font-extrabold text-[#1e1b18] mt-0.5 truncate">
              {attempt.examTitle}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-[#fdfbf7] border border-[#eee5d9]">
            <p className="text-[#7a6f62] uppercase font-bold text-[10px]">
              {language === 'gu' ? 'લીધેલ સમય' : 'Time Taken'}
            </p>
            <p className="text-sm font-extrabold text-[#1e1b18] mt-0.5 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-[#8c4e28]" />
              {timeTakenFormatted}
            </p>
          </div>
        </div>

        {/* Score and Key Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-center">
          <div className="p-3 rounded-2xl bg-white border border-[#e5dcd1]">
            <p className="text-[10px] font-bold text-[#7a6f62] uppercase">
              {language === 'gu' ? 'કુલ પ્રશ્નો' : 'Total MCQs'}
            </p>
            <p className="text-xl font-extrabold text-[#1e1b18] mt-1">{attempt.totalQuestions}</p>
          </div>

          <div className="p-3 rounded-2xl bg-white border border-[#e5dcd1]">
            <p className="text-[10px] font-bold text-[#7a6f62] uppercase">
              {language === 'gu' ? 'પ્રયાસ કરેલ' : 'Attempted'}
            </p>
            <p className="text-xl font-extrabold text-blue-700 mt-1">{attempt.attemptedQuestions}</p>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
            <p className="text-[10px] font-bold text-emerald-800 uppercase">
              {language === 'gu' ? 'સાચા જવાબો' : 'Correct'}
            </p>
            <p className="text-xl font-extrabold text-emerald-700 mt-1">{attempt.correctAnswers}</p>
          </div>

          <div className="p-3 rounded-2xl bg-red-50 border border-red-200">
            <p className="text-[10px] font-bold text-red-800 uppercase">
              {language === 'gu' ? 'ખોટા જવાબો' : 'Incorrect'}
            </p>
            <p className="text-xl font-extrabold text-red-700 mt-1">{attempt.wrongAnswers}</p>
          </div>

          <div className="p-3 rounded-2xl bg-white border border-[#e5dcd1]">
            <p className="text-[10px] font-bold text-[#7a6f62] uppercase">
              {language === 'gu' ? 'અનુત્તર (બાકી)' : 'Skipped'}
            </p>
            <p className="text-xl font-extrabold text-gray-600 mt-1">{attempt.unansweredQuestions}</p>
          </div>

          <div className="p-3 rounded-2xl bg-[#8c4e28] text-white">
            <p className="text-[10px] font-bold uppercase text-[#f7d9c6]">
              {language === 'gu' ? 'કુલ માર્ક્સ (%)' : 'Score & %'}
            </p>
            <p className="text-xl font-extrabold text-white mt-1">
              {attempt.totalMarksScored} <span className="text-xs">({attempt.percentage}%)</span>
            </p>
          </div>
        </div>

        {/* Motivational Banner */}
        <div className="mt-6 p-4 rounded-2xl bg-[#f5efe6] border border-[#e2d6c6] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#8c4e28] text-white flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-amber-300" />
          </div>
          <div className="text-xs">
            <p className="font-bold text-[#1e1b18]">
              {attempt.isPassed
                ? language === 'gu'
                  ? 'અભિનંદન! તમે AIBE પાસિંગ માપદંડ (૪૦%) પૂર્ણ કર્યો છે!'
                  : 'Congratulations! You have successfully met the AIBE passing standard (40% qualify score)!'
                : language === 'gu'
                ? 'સારી કોશિશ! પ્રશ્નોની કાયદાકીય સમજૂતી અને કેસ લો વાંચીને પુનરાવર્તન કરો.'
                : 'Good attempt! Review the legal explanations, statutory sections, and landmark case laws below to excel in AIBE.'}
            </p>
            <p className="text-[#7a6f62] mt-0.5">
              R. Karia Publication – Authoritative reference solutions for aspiring advocates.
            </p>
          </div>
        </div>
      </div>

      {/* Question-by-Question Solution Review Section */}
      <div className="space-y-4">
        <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-[#1e1b18] font-serif-legal">
              {language === 'gu'
                ? 'પ્રશ્નવાર વિગતવાર કાયદાકીય સમજૂતી (Question Solutions)'
                : 'Question-Wise Detailed Legal Solutions'}
            </h3>
            <p className="text-xs text-[#7a6f62]">
              {language === 'gu'
                ? 'દરેક પ્રશ્ન માટે સાચો જવાબ, સંબંધિત કાયદાકીય કલમ અને સીમાચિહ્ન કેસ લો.'
                : 'Review correct answers, relevant statutory provisions, and landmark case laws.'}
            </p>
          </div>

          {/* Solution Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setFilter('all')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                filter === 'all'
                  ? 'bg-[#8c4e28] text-white'
                  : 'bg-white text-[#5c5042] border border-[#e0d6c8]'
              }`}
            >
              All ({questionReviews.length})
            </button>
            <button
              onClick={() => setFilter('correct')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                filter === 'correct'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-emerald-800 border border-emerald-200'
              }`}
            >
              Correct ({attempt.correctAnswers})
            </button>
            <button
              onClick={() => setFilter('wrong')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                filter === 'wrong'
                  ? 'bg-red-600 text-white'
                  : 'bg-white text-red-800 border border-red-200'
              }`}
            >
              Incorrect ({attempt.wrongAnswers})
            </button>
            <button
              onClick={() => setFilter('unanswered')}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition ${
                filter === 'unanswered'
                  ? 'bg-gray-700 text-white'
                  : 'bg-white text-gray-700 border border-gray-300'
              }`}
            >
              Unanswered ({attempt.unansweredQuestions})
            </button>
          </div>
        </div>

        {/* Detailed Questions List */}
        <div className="space-y-4">
          {filteredReviews.map((item, idx) => {
            const q = item.question;
            if (!q) return null;

            const isCorrect = item.isCorrect;
            const isUnanswered = item.isUnanswered;

            const qText =
              language === 'gu' && q.questionTextGu ? q.questionTextGu : q.questionText;
            const explanation =
              language === 'gu' && q.explanationGu ? q.explanationGu : q.explanation;

            return (
              <div
                key={item.questionId}
                className={`rounded-2xl border p-5 sm:p-6 transition ${
                  isCorrect
                    ? 'bg-emerald-50/40 border-emerald-200'
                    : isUnanswered
                    ? 'bg-gray-50/60 border-gray-200'
                    : 'bg-red-50/40 border-red-200'
                }`}
              >
                {/* Result Status Banner */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#8c4e28] text-white font-mono text-xs font-bold">
                      Q.{idx + 1}
                    </span>
                    <span className="text-xs font-semibold text-[#8c4e28] px-2 py-0.5 rounded-md bg-[#8c4e28]/10">
                      {q.subject}
                    </span>
                  </div>

                  {/* Animation and Feedback Badge */}
                  {isCorrect && (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-extrabold shadow-xs animate-bounce">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>
                        {language === 'gu'
                          ? 'અભિનંદન! તમારો જવાબ સાચો છે!'
                          : 'Congratulations! Your Answer is Correct!'}
                      </span>
                      <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                    </div>
                  )}

                  {!isCorrect && !isUnanswered && (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white text-xs font-bold shadow-xs">
                      <X className="w-4 h-4 stroke-[3]" />
                      <span>{language === 'gu' ? 'ખોટો જવાબ' : 'Incorrect Answer'}</span>
                    </div>
                  )}

                  {isUnanswered && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-gray-200 text-gray-700 text-xs font-bold">
                      <span>{language === 'gu' ? 'પ્રયાસ નથી કર્યો' : 'Not Attempted'}</span>
                    </div>
                  )}
                </div>

                {/* Question Text */}
                <h4 className="text-sm sm:text-base font-bold text-[#1e1b18] leading-relaxed">
                  {qText}
                </h4>

                {/* Option Breakdown */}
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
                    const optText =
                      language === 'gu' && q[`option${optKey}Gu` as keyof Question]
                        ? (q[`option${optKey}Gu` as keyof Question] as string)
                        : (q[`option${optKey}` as keyof Question] as string);

                    const isSelected = item.selectedOption === optKey;
                    const isRightAnswer = q.correctAnswer === optKey;

                    let optStyle = 'bg-white border-[#e5dcd1] text-[#332d26]';
                    if (isRightAnswer) {
                      optStyle = 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold';
                    } else if (isSelected && !isRightAnswer) {
                      optStyle = 'bg-red-100 border-red-500 text-red-950 line-through';
                    }

                    return (
                      <div
                        key={optKey}
                        className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${optStyle}`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-md bg-black/5 flex items-center justify-center font-bold text-[10px]">
                            {optKey}
                          </span>
                          <span>{optText}</span>
                        </div>
                        {isRightAnswer && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-600 text-white">
                            {language === 'gu' ? 'સાચો' : 'Correct'}
                          </span>
                        )}
                        {isSelected && !isRightAnswer && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-red-600 text-white">
                            {language === 'gu' ? 'તમારો' : 'Your Choice'}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Detailed Legal Explanation & Section & Case Law */}
                <div className="mt-4 pt-3 border-t border-black/10 text-xs space-y-2">
                  <div className="flex items-start gap-2">
                    <BookOpen className="w-4 h-4 text-[#8c4e28] shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-bold text-[#8c4e28]">
                        {language === 'gu' ? 'વિગતવાર કાયદાકીય સમજૂતી:' : 'Detailed Legal Explanation:'}
                      </p>
                      <p className="text-[#3a332c] mt-0.5 leading-relaxed">{explanation}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1 pl-6">
                    {q.legalSection && (
                      <span className="inline-block px-2.5 py-1 rounded-lg bg-[#8c4e28]/10 text-[#8c4e28] font-bold text-[11px]">
                        ⚖️ {q.legalSection}
                      </span>
                    )}
                    {q.caseLaw && (
                      <span className="inline-block px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-bold text-[11px] border border-blue-200">
                        📖 {q.caseLaw}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
