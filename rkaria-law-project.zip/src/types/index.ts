/**
 * R. KARIA PUBLICATION – LAW STUDENT PAPER SOLUTION
 * Core Data Types
 */

export type Subject =
  | 'Constitutional Law'
  | 'Indian Penal Code / BNS'
  | 'Criminal Procedure Code / BNSS'
  | 'Code of Civil Procedure (CPC)'
  | 'Indian Evidence Act / BSA'
  | 'Law of Contract & Specific Relief'
  | 'Family Law (Hindu & Muslim)'
  | 'Arbitration & ADR'
  | 'Professional Ethics & Bar Council Rules'
  | 'Public Interest Litigation (PIL)'
  | 'Company Law'
  | 'Environmental & Cyber Law'
  | 'Administrative Law & Tort';

export interface Question {
  id: string;
  questionNumber?: number;
  questionText: string;
  questionTextGu?: string; // Gujarati translation
  optionA: string;
  optionAGu?: string;
  optionB: string;
  optionBGu?: string;
  optionC: string;
  optionCGu?: string;
  optionD: string;
  optionDGu?: string;
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  explanationGu?: string;
  subject: Subject | string;
  legalSection?: string; // e.g. "Article 21, Constitution of India" / "Section 300, IPC"
  caseLaw?: string; // e.g. "Maneka Gandhi v. Union of India (1978)"
}

export interface Exam {
  id: string;
  title: string;
  titleGu?: string;
  description: string;
  descriptionGu?: string;
  category: 'AIBE Mock Test' | 'Subject-Wise MCQ Test' | 'Practice Examination';
  durationMinutes: number; // e.g., 180 for 200 questions, or 60
  totalQuestions: number; // e.g., 200
  totalMarks: number;
  passingMarks: number; // AIBE is 40% (80/200)
  negativeMarking: boolean; // default false for AIBE
  negativeMarkingValue?: number; // e.g. 0.25
  isPublished: boolean;
  questionIds: string[];
  createdAt: string;
}

export interface Student {
  id: string;
  fullName: string;
  mobileNumber: string;
  registeredAt: string;
  lastLoginAt: string;
}

export interface StudentAnswer {
  questionId: string;
  selectedOption: 'A' | 'B' | 'C' | 'D' | null;
  isMarkedForReview: boolean;
  timeSpentSeconds?: number;
}

export interface ExamAttempt {
  id: string;
  studentId: string;
  studentName: string;
  studentMobile: string;
  examId: string;
  examTitle: string;
  startedAt: string;
  submittedAt: string;
  totalQuestions: number;
  attemptedQuestions: number;
  unansweredQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  totalMarksScored: number;
  maxMarks: number;
  percentage: number;
  isPassed: boolean;
  timeTakenSeconds: number;
  answers: Record<string, StudentAnswer>; // questionId -> answer
}

export interface ExamSessionState {
  attemptId: string;
  examId: string;
  studentId: string;
  startedAt: string;
  timeRemainingSeconds: number;
  answers: Record<string, StudentAnswer>;
  currentQuestionIndex: number;
  language: 'en' | 'gu';
}
