/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/common/Header';
import { OfflineBanner } from './components/common/OfflineBanner';
import { StudentRegisterModal } from './components/student/StudentRegisterModal';
import { StudentDashboard } from './components/student/StudentDashboard';
import { ExamRunner } from './components/exam/ExamRunner';
import { ExamResultView } from './components/exam/ExamResultView';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { Exam, ExamAttempt, Student } from './types';
import {
  getCurrentStudent,
  setCurrentStudent,
  isAdminAuthenticated,
  getExamById,
  getAllExams,
  getActiveExamSession,
} from './services/storage';

export default function App() {
  const [currentStudent, setCurrentStudentState] = useState<Student | null>(getCurrentStudent());
  const [currentView, setCurrentView] = useState<'dashboard' | 'exam' | 'result' | 'admin'>('dashboard');
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [activeAttempt, setActiveAttempt] = useState<ExamAttempt | null>(null);

  // Modals
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [language, setLanguage] = useState<'en' | 'gu'>('en');

  // Check URL query parameters for direct WhatsApp examination links (e.g. ?examId=...)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const examId = params.get('examId');

    if (examId) {
      const exam = getExamById(examId);
      if (exam) {
        setActiveExam(exam);
        const student = getCurrentStudent();
        if (student) {
          setCurrentView('exam');
        } else {
          // Open registration modal for new students coming from WhatsApp
          setIsRegisterModalOpen(true);
        }
      }
    } else {
      // Check if an exam was already in progress
      const session = getActiveExamSession();
      if (session && currentStudent && session.studentId === currentStudent.id) {
        const exam = getExamById(session.examId);
        if (exam) {
          setActiveExam(exam);
          setCurrentView('exam');
        }
      }
    }
  }, []);

  const handleStartExam = (exam: Exam) => {
    if (!currentStudent) {
      setActiveExam(exam);
      setIsRegisterModalOpen(true);
      return;
    }
    setActiveExam(exam);
    setCurrentView('exam');
  };

  const handleFinishExam = (attempt: ExamAttempt) => {
    setActiveAttempt(attempt);
    setCurrentView('result');
  };

  const handleViewAttempt = (attempt: ExamAttempt) => {
    setActiveAttempt(attempt);
    setCurrentView('result');
  };

  const handleStudentRegistered = (student: Student) => {
    setCurrentStudentState(student);
    if (activeExam) {
      setCurrentView('exam');
    } else {
      setCurrentView('dashboard');
    }
  };

  const handleLogoutStudent = () => {
    setCurrentStudent(null);
    setCurrentStudentState(null);
    setCurrentView('dashboard');
  };

  const handleOpenAdminPortal = () => {
    if (isAdminAuthenticated()) {
      setCurrentView('admin');
    } else {
      setIsAdminModalOpen(true);
    }
  };

  const handleToggleLanguage = () => {
    setLanguage((prev) => (prev === 'en' ? 'gu' : 'en'));
  };

  // If in active examination mode, render full-screen ExamRunner
  if (currentView === 'exam' && activeExam && currentStudent) {
    return (
      <>
        <ExamRunner
          exam={activeExam}
          student={currentStudent}
          onFinishExam={handleFinishExam}
          onExitExam={() => setCurrentView('dashboard')}
          language={language}
          onToggleLanguage={handleToggleLanguage}
        />
        <OfflineBanner />
      </>
    );
  }

  // If viewing admin portal
  if (currentView === 'admin') {
    return (
      <>
        <AdminDashboard
          onBackToApp={() => setCurrentView('dashboard')}
          language={language}
        />
        <OfflineBanner />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#fdfbf7] flex flex-col">
      {/* Top Header */}
      <Header
        currentStudent={currentStudent}
        onOpenStudentModal={() => setIsRegisterModalOpen(true)}
        onLogoutStudent={handleLogoutStudent}
        onOpenAdmin={handleOpenAdminPortal}
        onGoHome={() => setCurrentView('dashboard')}
        language={language}
        onToggleLanguage={handleToggleLanguage}
      />

      {/* Main Body */}
      <main className="flex-1">
        {currentView === 'dashboard' && (
          <StudentDashboard
            currentStudent={currentStudent}
            onStartExam={handleStartExam}
            onViewAttempt={handleViewAttempt}
            onOpenRegisterModal={() => setIsRegisterModalOpen(true)}
            language={language}
          />
        )}

        {currentView === 'result' && activeAttempt && (
          <ExamResultView
            attempt={activeAttempt}
            onBackToDashboard={() => setCurrentView('dashboard')}
            language={language}
          />
        )}
      </main>

      {/* Publication Footer */}
      <footer className="no-print mt-12 py-8 bg-[#1e1b18] text-[#d4c6b8] border-t border-[#3a3229] text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg overflow-hidden border border-[#c47a46]/40 bg-[#1e1b18] p-0.5 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-11_at_12.56.17_PM_7e5c099b.jpeg"
                alt="R. Karia Publication"
                className="w-full h-full object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/icon.svg';
                }}
              />
            </div>
            <div>
              <p className="font-bold text-[#fdfbf7] font-serif-legal">
                R. KARIA PUBLICATION
              </p>
              <p className="text-[10px] text-[#c47a46] font-semibold">
                LAW STUDENT PAPER SOLUTION
              </p>
            </div>
          </div>

          <div className="text-center sm:text-right text-[11px] text-[#9c8e7f]">
            <p>
              All India Bar Examination (AIBE) Preparatory Online Test Engine.
            </p>
            <p className="mt-0.5">
              Designed for Law Students & Bar Aspirants across India.
            </p>
          </div>
        </div>
      </footer>

      {/* Modals & Offline Indicator */}
      <StudentRegisterModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
        onSuccess={handleStudentRegistered}
        language={language}
      />

      <AdminLoginModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        onLoginSuccess={() => setCurrentView('admin')}
      />

      <OfflineBanner />
    </div>
  );
}
