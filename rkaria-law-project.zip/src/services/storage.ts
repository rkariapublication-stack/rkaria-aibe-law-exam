/**
 * R. KARIA PUBLICATION – LAW STUDENT PAPER SOLUTION
 * Persistent Storage & Evaluation Engine
 */

import { Exam, ExamAttempt, ExamSessionState, Question, Student, StudentAnswer } from '../types';
import { generateFull200QuestionBank } from '../data/questionBank';
import { INITIAL_EXAMS } from '../data/sampleExams';

const STORAGE_KEYS = {
  QUESTIONS: 'rkaria_questions_v1',
  EXAMS: 'rkaria_exams_v1',
  STUDENTS: 'rkaria_students_v1',
  ATTEMPTS: 'rkaria_attempts_v1',
  CURRENT_STUDENT: 'rkaria_current_student',
  ADMIN_SESSION: 'rkaria_admin_session',
  ACTIVE_EXAM_SESSION: 'rkaria_active_exam_session',
  SETTINGS: 'rkaria_settings',
};

// Seed initial data if not present
function initializeStorage() {
  if (typeof window === 'undefined') return;

  if (!localStorage.getItem(STORAGE_KEYS.QUESTIONS)) {
    const fullBank = generateFull200QuestionBank();
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(fullBank));
  }

  if (!localStorage.getItem(STORAGE_KEYS.EXAMS)) {
    localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(INITIAL_EXAMS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.STUDENTS)) {
    // Add sample student for instant demonstration
    const sampleStudents: Student[] = [
      {
        id: 'std-sample-1',
        fullName: 'Adv. Rajesh Sharma',
        mobileNumber: '9876543210',
        registeredAt: new Date(Date.now() - 86400000 * 3).toISOString(),
        lastLoginAt: new Date().toISOString(),
      },
    ];
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(sampleStudents));
  }

  if (!localStorage.getItem(STORAGE_KEYS.ATTEMPTS)) {
    localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify([]));
  }
}

// Run initialization immediately on load
initializeStorage();

// ================= STUDENTS ================= //

export function getAllStudents(): Student[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    return data ? JSON.parse(data) : [];
  } catch (err) {
    console.error('Failed to get students', err);
    return [];
  }
}

export function getStudentByMobile(mobileNumber: string): Student | undefined {
  const cleanMobile = mobileNumber.trim().replace(/\D/g, '');
  const students = getAllStudents();
  return students.find((s) => s.mobileNumber.replace(/\D/g, '') === cleanMobile);
}

export function registerOrLoginStudent(fullName: string, mobileNumber: string): { student: Student; isExisting: boolean } {
  const cleanMobile = mobileNumber.trim().replace(/\D/g, '');
  const cleanName = fullName.trim();
  const students = getAllStudents();

  const existingIndex = students.findIndex((s) => s.mobileNumber.replace(/\D/g, '') === cleanMobile);

  if (existingIndex >= 0) {
    // Existing student: update lastLoginAt and name if updated
    const existing = students[existingIndex];
    const updated: Student = {
      ...existing,
      fullName: cleanName || existing.fullName,
      lastLoginAt: new Date().toISOString(),
    };
    students[existingIndex] = updated;
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    setCurrentStudent(updated);
    return { student: updated, isExisting: true };
  }

  // New registration
  const newStudent: Student = {
    id: `std-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    fullName: cleanName,
    mobileNumber: cleanMobile,
    registeredAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  students.push(newStudent);
  localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  setCurrentStudent(newStudent);
  return { student: newStudent, isExisting: false };
}

export function getCurrentStudent(): Student | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_STUDENT);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setCurrentStudent(student: Student | null) {
  if (student) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_STUDENT, JSON.stringify(student));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_STUDENT);
  }
}

// ================= QUESTIONS ================= //

export function getAllQuestions(): Question[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
    if (!data) {
      const generated = generateFull200QuestionBank();
      localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(generated));
      return generated;
    }
    return JSON.parse(data);
  } catch (err) {
    console.error('Failed to get questions', err);
    return generateFull200QuestionBank();
  }
}

export function getQuestionById(id: string): Question | undefined {
  const questions = getAllQuestions();
  return questions.find((q) => q.id === id);
}

export function saveQuestion(question: Question): Question {
  const questions = getAllQuestions();
  const idx = questions.findIndex((q) => q.id === question.id);
  if (idx >= 0) {
    questions[idx] = question;
  } else {
    questions.push(question);
  }
  localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
  return question;
}

export function deleteQuestion(id: string): boolean {
  const questions = getAllQuestions();
  const filtered = questions.filter((q) => q.id !== id);
  if (filtered.length !== questions.length) {
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(filtered));
    return true;
  }
  return false;
}

export function bulkImportQuestions(newQuestions: Question[]): { count: number; total: number } {
  const existing = getAllQuestions();
  const existingIds = new Set(existing.map((q) => q.id));

  let addedCount = 0;
  for (const q of newQuestions) {
    if (!existingIds.has(q.id)) {
      existing.push(q);
      existingIds.add(q.id);
      addedCount++;
    } else {
      const idx = existing.findIndex((eq) => eq.id === q.id);
      if (idx >= 0) existing[idx] = q;
    }
  }

  localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(existing));
  return { count: addedCount, total: existing.length };
}

// ================= EXAMS ================= //

export function getAllExams(): Exam[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.EXAMS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(INITIAL_EXAMS));
      return INITIAL_EXAMS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_EXAMS;
  }
}

export function getExamById(id: string): Exam | undefined {
  const exams = getAllExams();
  return exams.find((e) => e.id === id);
}

export function saveExam(exam: Exam): Exam {
  const exams = getAllExams();
  const idx = exams.findIndex((e) => e.id === exam.id);
  if (idx >= 0) {
    exams[idx] = exam;
  } else {
    exams.push(exam);
  }
  localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(exams));
  return exam;
}

export function deleteExam(id: string): boolean {
  const exams = getAllExams();
  const filtered = exams.filter((e) => e.id !== id);
  if (filtered.length !== exams.length) {
    localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(filtered));
    return true;
  }
  return false;
}

// ================= IN-PROGRESS EXAM AUTO-SAVE ================= //

export function getActiveExamSession(): ExamSessionState | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_EXAM_SESSION);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function saveActiveExamSession(session: ExamSessionState) {
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_EXAM_SESSION, JSON.stringify(session));
  } catch (err) {
    console.error('Failed to auto-save exam session', err);
  }
}

export function clearActiveExamSession() {
  localStorage.removeItem(STORAGE_KEYS.ACTIVE_EXAM_SESSION);
}

// ================= EXAM ATTEMPTS & GRADING ================= //

export function getAllAttempts(): ExamAttempt[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ATTEMPTS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function getAttemptsByStudent(studentId: string): ExamAttempt[] {
  const attempts = getAllAttempts();
  return attempts
    .filter((a) => a.studentId === studentId)
    .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
}

export function getAttemptById(attemptId: string): ExamAttempt | undefined {
  const attempts = getAllAttempts();
  return attempts.find((a) => a.id === attemptId);
}

/**
 * Server-like automatic grading engine.
 * Correct answers are evaluated safely here post-submission.
 */
export function submitExamAttempt(params: {
  student: Student;
  exam: Exam;
  answers: Record<string, StudentAnswer>;
  timeTakenSeconds: number;
  startedAt: string;
}): ExamAttempt {
  const { student, exam, answers, timeTakenSeconds, startedAt } = params;
  const allQuestions = getAllQuestions();
  const questionMap = new Map(allQuestions.map((q) => [q.id, q]));

  let correctCount = 0;
  let wrongCount = 0;
  let attemptedCount = 0;

  for (const qId of exam.questionIds) {
    const q = questionMap.get(qId);
    const ans = answers[qId];

    if (ans && ans.selectedOption) {
      attemptedCount++;
      if (q && ans.selectedOption === q.correctAnswer) {
        correctCount++;
      } else {
        wrongCount++;
      }
    }
  }

  const unansweredCount = exam.totalQuestions - attemptedCount;

  // Calculate score
  let marks = correctCount;
  if (exam.negativeMarking && exam.negativeMarkingValue) {
    marks = Math.max(0, marks - wrongCount * exam.negativeMarkingValue);
  }

  const percentage = Math.round((marks / exam.totalMarks) * 100);
  const isPassed = marks >= exam.passingMarks;

  const attempt: ExamAttempt = {
    id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    studentId: student.id,
    studentName: student.fullName,
    studentMobile: student.mobileNumber,
    examId: exam.id,
    examTitle: exam.title,
    startedAt,
    submittedAt: new Date().toISOString(),
    totalQuestions: exam.totalQuestions,
    attemptedQuestions: attemptedCount,
    unansweredQuestions: unansweredCount,
    correctAnswers: correctCount,
    wrongAnswers: wrongCount,
    totalMarksScored: Math.round(marks * 100) / 100,
    maxMarks: exam.totalMarks,
    percentage,
    isPassed,
    timeTakenSeconds,
    answers,
  };

  const attempts = getAllAttempts();
  attempts.unshift(attempt);
  localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(attempts));

  // Clear session cache
  clearActiveExamSession();

  return attempt;
}

// ================= ADMIN AUTH ================= //

export function isAdminAuthenticated(): boolean {
  return localStorage.getItem(STORAGE_KEYS.ADMIN_SESSION) === 'true';
}

export function setAdminAuthenticated(val: boolean) {
  if (val) {
    localStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, 'true');
  } else {
    localStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
  }
}

export function verifyAdminCredentials(user: string, pass: string): boolean {
  const cleanUser = user.trim().toLowerCase();
  const cleanPass = pass.trim();

  // Standard publication admin credentials
  if (
    (cleanUser === 'admin' || cleanUser === 'admin@rkaria.com' || cleanUser === 'kariaassociates414@gmail.com') &&
    (cleanPass === 'rkaria@aibe2026' || cleanPass === 'admin123' || cleanPass === 'aibe2026')
  ) {
    setAdminAuthenticated(true);
    return true;
  }
  return false;
}

// ================= BACKUP & RESTORE ================= //

export function exportFullBackupJSON(): string {
  const data = {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    students: getAllStudents(),
    exams: getAllExams(),
    questions: getAllQuestions(),
    attempts: getAllAttempts(),
  };
  return JSON.stringify(data, null, 2);
}

export function importFullBackupJSON(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (data.questions) localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(data.questions));
    if (data.exams) localStorage.setItem(STORAGE_KEYS.EXAMS, JSON.stringify(data.exams));
    if (data.students) localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(data.students));
    if (data.attempts) localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(data.attempts));
    return true;
  } catch (err) {
    console.error('Failed to import backup', err);
    return false;
  }
}
