/**
 * R. KARIA PUBLICATION – LAW STUDENT PAPER SOLUTION
 * CSV / Excel Export, Bulk Question Upload Parser & WhatsApp Link Generator
 */

import { ExamAttempt, Question, Student } from '../types';

/**
 * Trigger browser file download from string content
 */
export function downloadFile(content: string, fileName: string, mimeType = 'text/csv;charset=utf-8;') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', fileName);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Generate CSV of Student Results
 */
export function exportAttemptsToCSV(attempts: ExamAttempt[]): string {
  const headers = [
    'Student Name',
    'Mobile Number',
    'Examination Title',
    'Date & Time',
    'Total Questions',
    'Attempted',
    'Unanswered',
    'Correct Answers',
    'Wrong Answers',
    'Total Marks',
    'Max Marks',
    'Percentage (%)',
    'Result Status',
    'Time Taken (Min:Sec)',
  ];

  const rows = attempts.map((a) => {
    const mins = Math.floor(a.timeTakenSeconds / 60);
    const secs = a.timeTakenSeconds % 60;
    const timeFormatted = `${mins}m ${secs}s`;

    return [
      `"${a.studentName.replace(/"/g, '""')}"`,
      `"${a.studentMobile}"`,
      `"${a.examTitle.replace(/"/g, '""')}"`,
      `"${new Date(a.submittedAt).toLocaleString()}"`,
      a.totalQuestions,
      a.attemptedQuestions,
      a.unansweredQuestions,
      a.correctAnswers,
      a.wrongAnswers,
      a.totalMarksScored,
      a.maxMarks,
      `${a.percentage}%`,
      a.isPassed ? 'PASSED' : 'NEEDS IMPROVEMENT',
      `"${timeFormatted}"`,
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Generate CSV of Registered Students
 */
export function exportStudentsToCSV(students: Student[], attempts: ExamAttempt[]): string {
  const headers = ['Student ID', 'Full Name', 'Mobile Number', 'Registration Date', 'Total Exams Attempted', 'Last Exam Date'];

  const rows = students.map((s) => {
    const studentAttempts = attempts.filter((a) => a.studentId === s.id);
    const lastAttempt = studentAttempts[0];

    return [
      `"${s.id}"`,
      `"${s.fullName.replace(/"/g, '""')}"`,
      `"${s.mobileNumber}"`,
      `"${new Date(s.registeredAt).toLocaleDateString()}"`,
      studentAttempts.length,
      lastAttempt ? `"${new Date(lastAttempt.submittedAt).toLocaleDateString()}"` : '"No Attempts Yet"',
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Generate Sample Excel / CSV Template for Question Bank Upload
 */
export function generateSampleQuestionsCSV(): string {
  const headers = [
    'Question Text (English)',
    'Question Text (Gujarati)',
    'Option A (English)',
    'Option A (Gujarati)',
    'Option B (English)',
    'Option B (Gujarati)',
    'Option C (English)',
    'Option C (Gujarati)',
    'Option D (English)',
    'Option D (Gujarati)',
    'Correct Answer (A/B/C/D)',
    'Detailed Explanation (English)',
    'Detailed Explanation (Gujarati)',
    'Subject',
    'Legal Section',
    'Case Law',
  ];

  const sampleRows = [
    [
      '"Under which Article is Right to Privacy recognized as a Fundamental Right?"',
      '"કયા અનુચ્છેદ હેઠળ ગોપનીયતાનો અધિકાર મૂળભૂત અધિકાર છે?"',
      '"Article 14"',
      '"અનુચ્છેદ ૧૪"',
      '"Article 19"',
      '"અનુચ્છેદ ૧૯"',
      '"Article 21"',
      '"અનુચ્છેદ ૨૧"',
      '"Article 32"',
      '"અનુચ્છેદ ૩૨"',
      '"C"',
      '"Right to privacy is an intrinsic part of right to life and personal liberty under Article 21."',
      '"અનુચ્છેદ ૨૧ હેઠળ ગોપનીયતાનો અધિકાર જીવનના અધિકારનો ભાગ છે."',
      '"Constitutional Law"',
      '"Article 21, Constitution of India"',
      '"K.S. Puttaswamy v. Union of India (2017)"',
    ].join(','),
    [
      '"What is the minimum number of persons required for Unlawful Assembly under Section 141 IPC?"',
      '"ગેરકાયદે મંડળી માટે ઓછામાં ઓછી કેટલી વ્યક્તિઓ જરૂરી છે?"',
      '"2 persons"',
      '"૨ વ્યક્તિઓ"',
      '"3 persons"',
      '"૩ વ્યક્તિઓ"',
      '"5 persons"',
      '"૫ વ્યક્તિઓ"',
      '"7 persons"',
      '"૭ વ્યક્તિઓ"',
      '"C"',
      '"An assembly of 5 or more persons with common illegal object."',
      '"સામાન્ય ગેરકાયદે હેતુ ધરાવતી ૫ કે તેથી વધુ વ્યક્તિઓ."',
      '"Indian Penal Code / BNS"',
      '"Section 141, IPC / Section 189, BNS"',
      '"State of U.P. v. Sughar Singh (1978)"',
    ].join(','),
  ];

  return [headers.join(','), ...sampleRows].join('\n');
}

export interface CSVValidationResult {
  validQuestions: Question[];
  errors: string[];
}

/**
 * Parse and validate uploaded questions CSV
 */
export function parseAndValidateQuestionsCSV(csvContent: string): CSVValidationResult {
  const lines = csvContent
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  const errors: string[] = [];
  const validQuestions: Question[] = [];

  if (lines.length <= 1) {
    errors.push('File is empty or contains only the header row.');
    return { validQuestions, errors };
  }

  // Parse CSV line handling quotes
  const parseLine = (text: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      if (char === '"') {
        if (inQuotes && text[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  // Skip header line
  for (let idx = 1; idx < lines.length; idx++) {
    const rowNum = idx + 1;
    const cols = parseLine(lines[idx]);

    if (cols.length < 12) {
      errors.push(`Row ${rowNum}: Insufficient columns (found ${cols.length}, expected at least 12).`);
      continue;
    }

    const [
      qEn,
      qGu,
      optAEn,
      optAGu,
      optBEn,
      optBGu,
      optCEn,
      optCGu,
      optDEn,
      optDGu,
      correctRaw,
      expEn,
      expGu,
      subject,
      sec,
      caseLaw,
    ] = cols;

    if (!qEn) {
      errors.push(`Row ${rowNum}: Question Text is missing.`);
      continue;
    }

    if (!optAEn || !optBEn || !optCEn || !optDEn) {
      errors.push(`Row ${rowNum}: One or more options (A, B, C, D) are missing.`);
      continue;
    }

    const correct = (correctRaw || '').trim().toUpperCase();
    if (!['A', 'B', 'C', 'D'].includes(correct)) {
      errors.push(`Row ${rowNum}: Invalid correct answer "${correctRaw}". Must be A, B, C, or D.`);
      continue;
    }

    if (!expEn) {
      errors.push(`Row ${rowNum}: Detailed Explanation is missing.`);
      continue;
    }

    validQuestions.push({
      id: `q-bulk-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 5)}`,
      questionText: qEn,
      questionTextGu: qGu || qEn,
      optionA: optAEn,
      optionAGu: optAGu || optAEn,
      optionB: optBEn,
      optionBGu: optBGu || optBEn,
      optionC: optCEn,
      optionCGu: optCGu || optCEn,
      optionD: optDEn,
      optionDGu: optDGu || optDEn,
      correctAnswer: correct as 'A' | 'B' | 'C' | 'D',
      explanation: expEn,
      explanationGu: expGu || expEn,
      subject: subject || 'Constitutional Law',
      legalSection: sec || undefined,
      caseLaw: caseLaw || undefined,
    });
  }

  return { validQuestions, errors };
}

/**
 * Generate formatted WhatsApp message and share URL
 */
export function generateWhatsAppShareData(examTitle: string, totalQuestions: number, examId: string) {
  // Use public window location origin or app URL
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const examUrl = `${origin}/?examId=${encodeURIComponent(examId)}`;

  const messageText = `*R. KARIA PUBLICATION*
*LAW STUDENT PAPER SOLUTION*

*AIBE ONLINE MOCK EXAMINATION*

Total Questions: ${totalQuestions}

Prepare for your All India Bar Examination with our online MCQ practice test.

Click the link below to start your examination:
${examUrl}

Best Wishes,
*R. KARIA PUBLICATION*`;

  const waShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(messageText)}`;

  return {
    messageText,
    examUrl,
    waShareUrl,
  };
}
